package com.streamsub.netflix.service;

import com.streamsub.netflix.dto.*;
import com.streamsub.netflix.exception.ConflictException;
import com.streamsub.netflix.exception.ResourceNotFoundException;
import com.streamsub.netflix.exception.UnauthorizedException;
import com.streamsub.netflix.model.Subscription;
import com.streamsub.netflix.repository.SubscriptionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SubscriptionServiceTest {

    @Mock
    private SubscriptionRepository repository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private KnowledgeBaseLoader knowledgeBaseLoader;

    private SubscriptionService service;

    @BeforeEach
    void setUp() {
        service = new SubscriptionService(repository, passwordEncoder, knowledgeBaseLoader);
    }

    // ==========================================
    // 1. LOGIN TESTS (Tested FIRST as required)
    // ==========================================

    @Test
    @DisplayName("Login Success: valid credentials return 200 with LoginResponse")
    void testLogin_Success() {
        Subscription mockSub = new Subscription();
        mockSub.setId(10L);
        mockSub.setUsername("john_doe");
        mockSub.setCustomerName("John Doe");
        mockSub.setPassword("$2a$10$hashedPasswordHere");

        when(repository.findByUsername("john_doe")).thenReturn(Optional.of(mockSub));
        when(passwordEncoder.matches("ValidPassword@123", "$2a$10$hashedPasswordHere")).thenReturn(true);

        LoginRequest req = new LoginRequest("john_doe", "ValidPassword@123");
        LoginResponse res = service.login(req);

        assertNotNull(res);
        assertEquals(10L, res.getSubscriptionId());
        assertEquals("john_doe", res.getUsername());
        assertNotNull(res.getToken());
    }

    @Test
    @DisplayName("Login Failure: wrong password returns 401 with generic message")
    void testLogin_WrongPassword() {
        Subscription mockSub = new Subscription();
        mockSub.setUsername("john_doe");
        mockSub.setPassword("$2a$10$hashedPasswordHere");

        when(repository.findByUsername("john_doe")).thenReturn(Optional.of(mockSub));
        when(passwordEncoder.matches("WrongPassword@999", "$2a$10$hashedPasswordHere")).thenReturn(false);

        LoginRequest req = new LoginRequest("john_doe", "WrongPassword@999");
        UnauthorizedException ex = assertThrows(UnauthorizedException.class, () -> service.login(req));
        assertEquals("Invalid credentials", ex.getMessage());
    }

    @Test
    @DisplayName("Login Failure: unknown username returns 401 with generic message (not revealing username)")
    void testLogin_UnknownUser() {
        when(repository.findByUsername("ghost_user")).thenReturn(Optional.empty());

        LoginRequest req = new LoginRequest("ghost_user", "AnyPassword@123");
        UnauthorizedException ex = assertThrows(UnauthorizedException.class, () -> service.login(req));
        assertEquals("Invalid credentials", ex.getMessage());
    }

    // ===========================================================
    // 2. REGISTRATION TESTS: ALL 4 PLANS x ALL 4 PAYMENT TYPES
    // ===========================================================

    @Test
    @DisplayName("Register: Valid registration across all 4 plans x 4 payment types calculates correct endDate & price")
    void testRegister_AllPlansAndPaymentTypes() {
        String[] plans = { "MOBILE", "BASIC", "STANDARD", "PREMIUM" };
        String[] paymentTypes = { "MONTHLY", "QUARTERLY", "HALF_YEARLY", "ANNUAL" };
        int[] expectedMonths = { 1, 3, 6, 12 };

        when(passwordEncoder.encode(anyString())).thenReturn("$2a$10$bcryptEncodedHash");
        when(knowledgeBaseLoader.getPrice(anyString(), anyString())).thenReturn(499.0);

        for (String plan : plans) {
            for (int i = 0; i < paymentTypes.length; i++) {
                String paymentType = paymentTypes[i];
                int months = expectedMonths[i];

                when(repository.findByEmailIdIgnoreCase(anyString())).thenReturn(Collections.emptyList());
                when(repository.existsByUsername(anyString())).thenReturn(false);
                when(repository.save(any(Subscription.class))).thenAnswer(invocation -> {
                    Subscription s = invocation.getArgument(0);
                    s.setId(100L);
                    return s;
                });

                RegisterRequest req = new RegisterRequest();
                req.setCustomerName("Alice Smith");
                req.setMobileNumber("9876543210");
                req.setEmailId("alice." + plan.toLowerCase() + "." + paymentType.toLowerCase() + "@example.com");
                req.setUsername("user_" + plan + "_" + paymentType);
                req.setPassword("SecretPass@2026");
                req.setConfirmPassword("SecretPass@2026");
                req.setPlanType(plan);
                req.setPaymentType(paymentType);
                req.setPaymentMethod("Credit Card");

                SubscriptionResponse res = service.register(req);

                assertNotNull(res);
                assertEquals("ACTIVE", res.getStatus());
                assertEquals(LocalDate.now(), res.getStartDate());
                assertEquals(LocalDate.now().plusMonths(months), res.getEndDate());
                assertEquals(499.0, res.getPrice());
                assertEquals("alice." + plan.toLowerCase() + "." + paymentType.toLowerCase() + "@example.com",
                        res.getEmailId());
            }
        }
    }

    // ==========================================
    // 3. DUPLICATE ACTIVE & USERNAME CHECKS
    // ==========================================

    @Test
    @DisplayName("Duplicate active subscription for email throws 409 ConflictException")
    void testRegister_DuplicateActiveEmail_Throws409() {
        Subscription existingActive = new Subscription();
        existingActive.setEmailId("dup@example.com");
        existingActive.setStatus("ACTIVE");

        when(repository.findByEmailIdIgnoreCase("dup@example.com")).thenReturn(List.of(existingActive));

        RegisterRequest req = new RegisterRequest();
        req.setCustomerName("Bob Builder");
        req.setMobileNumber("9876543210");
        req.setEmailId("dup@example.com");
        req.setUsername("bob123");
        req.setPassword("ValidPass@123");
        req.setPlanType("BASIC");
        req.setPaymentType("MONTHLY");
        req.setPaymentMethod("UPI");

        ConflictException ex = assertThrows(ConflictException.class, () -> service.register(req));
        assertTrue(ex.getMessage().contains("active subscription already exists"));
    }

    @Test
    @DisplayName("Re-registration allowed when all prior subscriptions for email are INACTIVE")
    void testRegister_AllInactivePriorSubscriptions_Allowed() {
        Subscription oldInactive = new Subscription();
        oldInactive.setEmailId("prior@example.com");
        oldInactive.setStatus("INACTIVE");

        when(repository.findByEmailIdIgnoreCase("prior@example.com")).thenReturn(List.of(oldInactive));
        when(repository.existsByUsername("new_user")).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("$2a$10$hash");
        when(knowledgeBaseLoader.getPrice(anyString(), anyString())).thenReturn(199.0);
        when(repository.save(any(Subscription.class))).thenAnswer(inv -> {
            Subscription s = inv.getArgument(0);
            s.setId(200L);
            return s;
        });

        RegisterRequest req = new RegisterRequest();
        req.setCustomerName("Reapplying User");
        req.setMobileNumber("9876543210");
        req.setEmailId("prior@example.com");
        req.setUsername("new_user");
        req.setPassword("ValidPass@123");
        req.setPlanType("BASIC");
        req.setPaymentType("MONTHLY");
        req.setPaymentMethod("Debit Card");

        SubscriptionResponse res = service.register(req);
        assertNotNull(res);
        assertEquals("ACTIVE", res.getStatus());
    }

    @Test
    @DisplayName("Duplicate username throws 409 ConflictException regardless of status")
    void testRegister_DuplicateUsername_Throws409() {
        when(repository.findByEmailIdIgnoreCase(anyString())).thenReturn(Collections.emptyList());
        when(repository.existsByUsername("taken_user")).thenReturn(true);

        RegisterRequest req = new RegisterRequest();
        req.setCustomerName("Charlie");
        req.setMobileNumber("9876543210");
        req.setEmailId("charlie@example.com");
        req.setUsername("taken_user");
        req.setPassword("ValidPass@123");
        req.setPlanType("STANDARD");
        req.setPaymentType("MONTHLY");
        req.setPaymentMethod("PayPal");

        ConflictException ex = assertThrows(ConflictException.class, () -> service.register(req));
        assertTrue(ex.getMessage().contains("Username already exists"));
    }

    // ==========================================
    // 4. GET SUBSCRIPTION TESTS
    // ==========================================

    @Test
    @DisplayName("Get Subscription: owner access returns 200 without password")
    void testGetSubscription_OwnerAccess() {
        Subscription sub = new Subscription();
        sub.setId(55L);
        sub.setUsername("owner_user");
        sub.setCustomerName("Owner Name");
        sub.setEmailId("owner@example.com");
        sub.setMobileNumber("9876543210");
        sub.setStatus("ACTIVE");
        sub.setPlanType("PREMIUM");
        sub.setPaymentType("ANNUAL");
        sub.setPassword("$2a$10$topSecretHash");

        when(repository.findById(55L)).thenReturn(Optional.of(sub));

        SubscriptionResponse res = service.getSubscription(55L, "owner_user");
        assertNotNull(res);
        assertEquals(55L, res.getId());
        assertEquals("Owner Name", res.getCustomerName());
    }

    @Test
    @DisplayName("Get Subscription: missing ID throws 404 ResourceNotFoundException")
    void testGetSubscription_NotFound_Throws404() {
        when(repository.findById(999L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getSubscription(999L, "any_user"));
    }

    @Test
    @DisplayName("Get Subscription: accessing another user's subscription throws 401 UnauthorizedException")
    void testGetSubscription_UnauthorizedUser_Throws401() {
        Subscription sub = new Subscription();
        sub.setId(10L);
        sub.setUsername("victim_user");

        when(repository.findById(10L)).thenReturn(Optional.of(sub));

        assertThrows(UnauthorizedException.class, () -> service.getSubscription(10L, "hacker_user"));
    }

    // ==========================================
    // 5. UPDATE SUBSCRIPTION TESTS
    // ==========================================

    @Test
    @DisplayName("Update Subscription: plan or payment change recalculates price and extends endDate from current endDate")
    void testUpdateSubscription_RecalculatesPriceAndEndDate() {
        Subscription sub = new Subscription();
        sub.setId(1L);
        sub.setUsername("test_user");
        sub.setPlanType("BASIC");
        sub.setPaymentType("MONTHLY");
        sub.setStartDate(LocalDate.of(2026, 1, 1));
        sub.setEndDate(LocalDate.of(2026, 2, 1)); // current end date
        sub.setPrice(199.0);

        when(repository.findByUsername("test_user")).thenReturn(Optional.of(sub));
        when(knowledgeBaseLoader.getPrice("PREMIUM", "QUARTERLY")).thenReturn(1819.0);
        when(repository.save(any(Subscription.class))).thenAnswer(inv -> inv.getArgument(0));

        UpdateRequest req = new UpdateRequest();
        req.setPlanType("PREMIUM");
        req.setPaymentType("QUARTERLY");

        SubscriptionResponse res = service.updateSubscription(req, "test_user");

        assertEquals("PREMIUM", res.getPlanType());
        assertEquals("QUARTERLY", res.getPaymentType());
        assertEquals(1819.0, res.getPrice());
        // End date should be currentEndDate + 3 months = 2026-05-01
        assertEquals(LocalDate.of(2026, 5, 1), res.getEndDate());
    }
}
