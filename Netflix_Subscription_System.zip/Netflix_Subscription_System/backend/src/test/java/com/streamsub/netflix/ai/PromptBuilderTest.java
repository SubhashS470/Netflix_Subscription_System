package com.streamsub.netflix.ai;

import com.streamsub.netflix.service.KnowledgeBaseLoader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PromptBuilderTest {

    private KnowledgeBaseLoader loader;
    private PromptBuilder promptBuilder;

    @BeforeEach
    void setUp() {
        loader = new KnowledgeBaseLoader();
        loader.init();
        promptBuilder = new PromptBuilder(loader);
    }

    @Test
    @DisplayName("PromptBuilder contains all 4 knowledge base sections and grounding rules")
    void testPromptBuilder_ContainsAllFourSections() {
        String systemPrompt = promptBuilder.buildSystemPrompt();

        assertNotNull(systemPrompt);
        assertTrue(systemPrompt.contains("content_catalog"), "System prompt must include content_catalog");
        assertTrue(systemPrompt.contains("subscription_plans"), "System prompt must include subscription_plans");
        assertTrue(systemPrompt.contains("policies"), "System prompt must include policies");
        assertTrue(systemPrompt.contains("faqs"), "System prompt must include faqs");
        assertTrue(systemPrompt.contains("support_information"), "System prompt must reference support_information");
        assertTrue(systemPrompt.contains("VALID JSON ONLY"), "System prompt must mandate JSON output only");
    }
}
