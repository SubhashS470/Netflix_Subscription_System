package com.streamsub.netflix.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.streamsub.netflix.ai.LlmClient;
import com.streamsub.netflix.dto.AiRequest;
import com.streamsub.netflix.dto.AiResponse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AiController.class)
public class AiControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LlmClient llmClient;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    @DisplayName("Content Query: returns 200 with titles, genre, reason, and rating")
    void testRecommend_ContentQuery() throws Exception {
        AiResponse mockResponse = AiResponse.content(
                List.of("Stranger Things", "Dark Shadows"),
                List.of("Sci-Fi", "Mystery"),
                "High rated thrilling mysteries with supernatural elements",
                List.of(8.7, 7.9));

        when(llmClient.generateResponse(anyString())).thenReturn(mockResponse);

        AiRequest req = new AiRequest("Recommend something thrilling like Stranger Things");

        mockMvc.perform(post("/api/ai/recommend")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.type").value("content"))
                .andExpect(jsonPath("$.titles[0]").value("Stranger Things"))
                .andExpect(jsonPath("$.genre[0]").value("Sci-Fi"))
                .andExpect(jsonPath("$.reason").value("High rated thrilling mysteries with supernatural elements"))
                .andExpect(jsonPath("$.rating[0]").value(8.7));
    }

    @Test
    @DisplayName("Policy Query: returns 200 with answer and source_section")
    void testRecommend_PolicyQuery() throws Exception {
        AiResponse mockResponse = AiResponse.policy(
                "Upon cancellation, your subscription status changes to Inactive and access continues until the end of your current billing period.",
                "policies");

        when(llmClient.generateResponse(anyString())).thenReturn(mockResponse);

        AiRequest req = new AiRequest("What happens if I cancel my plan?");

        mockMvc.perform(post("/api/ai/recommend")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.type").value("policy"))
                .andExpect(jsonPath("$.answer").value(
                        "Upon cancellation, your subscription status changes to Inactive and access continues until the end of your current billing period."))
                .andExpect(jsonPath("$.source_section").value("policies"));
    }

    @Test
    @DisplayName("Blank Query: returns 400 Bad Request")
    void testRecommend_BlankQuery_Returns400() throws Exception {
        AiRequest req = new AiRequest("");

        mockMvc.perform(post("/api/ai/recommend")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isBadRequest());
    }
}
