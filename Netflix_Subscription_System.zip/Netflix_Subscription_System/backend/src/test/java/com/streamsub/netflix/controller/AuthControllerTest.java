package com.streamsub.netflix.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.streamsub.netflix.dto.AvailabilityResponse;
import com.streamsub.netflix.dto.RegisterRequest;
import com.streamsub.netflix.dto.SubscriptionResponse;
import com.streamsub.netflix.service.SubscriptionService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
public class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SubscriptionService subscriptionService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    @DisplayName("Register: valid request returns 201 Created and SubscriptionResponse without password")
    void testRegister_Returns201() throws Exception {
        SubscriptionResponse mockRes = new SubscriptionResponse(
                1L, "Alice Wonder", "9876543210", "alice@example.com",
                "STANDARD", "MONTHLY", LocalDate.now(), LocalDate.now().plusMonths(1),
                "ACTIVE", "Credit Card", "alice_w", 499.0, true, "123 Elm St", "Sci-Fi");

        when(subscriptionService.register(any(RegisterRequest.class))).thenReturn(mockRes);

        RegisterRequest req = new RegisterRequest();
        req.setCustomerName("Alice Wonder");
        req.setMobileNumber("9876543210");
        req.setEmailId("alice@example.com");
        req.setUsername("alice_w");
        req.setPassword("SecurePass@123");
        req.setPlanType("STANDARD");
        req.setPaymentType("MONTHLY");
        req.setPaymentMethod("Credit Card");

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.customerName").value("Alice Wonder"))
                .andExpect(jsonPath("$.status").value("ACTIVE"))
                .andExpect(jsonPath("$.password").doesNotExist());
    }

    @Test
    @DisplayName("Check Email Availability: returns 200 with available boolean")
    void testCheckEmail() throws Exception {
        when(subscriptionService.checkEmail(eq("available@example.com")))
                .thenReturn(new AvailabilityResponse(true));

        mockMvc.perform(get("/api/auth/check-email").param("email", "available@example.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.available").value(true));
    }

    @Test
    @DisplayName("Check Username Availability: returns 200 with available boolean")
    void testCheckUsername() throws Exception {
        when(subscriptionService.checkUsername(eq("free_username")))
                .thenReturn(new AvailabilityResponse(true));

        mockMvc.perform(get("/api/auth/check-username").param("username", "free_username"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.available").value(true));
    }
}
