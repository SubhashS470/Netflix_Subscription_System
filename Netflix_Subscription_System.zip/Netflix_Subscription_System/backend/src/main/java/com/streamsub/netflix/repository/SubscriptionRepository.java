package com.streamsub.netflix.repository;

import com.streamsub.netflix.model.Subscription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {

    Optional<Subscription> findByUsername(String username);

    boolean existsByUsername(String username);

    List<Subscription> findByEmailIdIgnoreCase(String emailId);

    boolean existsByEmailIdIgnoreCaseAndStatus(String emailId, String status);

    Optional<Subscription> findByEmailIdIgnoreCaseAndStatus(String emailId, String status);
}
