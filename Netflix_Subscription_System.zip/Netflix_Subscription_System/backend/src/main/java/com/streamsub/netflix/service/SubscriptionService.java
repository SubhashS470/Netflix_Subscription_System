package com.streamsub.netflix.service;

import com.streamsub.netflix.dto.*;
import com.streamsub.netflix.exception.ConflictException;
import com.streamsub.netflix.exception.ResourceNotFoundException;
import com.streamsub.netflix.exception.UnauthorizedException;
import com.streamsub.netflix.model.Subscription;
import com.streamsub.netflix.repository.SubscriptionRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

@Service
@Transactional
public class SubscriptionService {

    private final SubscriptionRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final KnowledgeBaseLoader knowledgeBaseLoader;

    public SubscriptionService(SubscriptionRepository repository,
            PasswordEncoder passwordEncoder,
            KnowledgeBaseLoader knowledgeBaseLoader) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
        this.knowledgeBaseLoader = knowledgeBaseLoader;
    }

    public SubscriptionResponse register(RegisterRequest request) {
        // Validate confirm password if provided
        if (request.getConfirmPassword() != null && !request.getConfirmPassword().isBlank()) {
            if (!request.getPassword().equals(request.getConfirmPassword())) {
                throw new IllegalArgumentException("Password and confirm password do not match");
            }
        }

        // Check for active subscription with email (case-insensitive)
        List<Subscription> existingByEmail = repository.findByEmailIdIgnoreCase(request.getEmailId().trim());
        boolean hasActive = existingByEmail.stream()
                .anyMatch(sub -> "ACTIVE".equalsIgnoreCase(sub.getStatus()));
        if (hasActive) {
            throw new ConflictException("An active subscription already exists for this email address");
        }

        // Check for duplicate username (case-insensitive)
        if (repository.existsByUsername(request.getUsername().trim())) {
            throw new ConflictException("Username already exists. Please choose a different username");
        }

        Subscription sub = new Subscription();
        sub.setCustomerName(request.getCustomerName().trim());
        sub.setMobileNumber(request.getMobileNumber().trim());
        sub.setEmailId(request.getEmailId().trim().toLowerCase(Locale.ROOT));
        sub.setUsername(request.getUsername().trim());

        // Password MUST be BCrypt hashed before saving
        sub.setPassword(passwordEncoder.encode(request.getPassword()));

        String normalizedPlan = normalizePlan(request.getPlanType());
        String normalizedPayment = normalizePaymentType(request.getPaymentType());
        sub.setPlanType(normalizedPlan);
        sub.setPaymentType(normalizedPayment);
        sub.setPaymentMethod(request.getPaymentMethod().trim());

        LocalDate start = LocalDate.now();
        sub.setStartDate(start);
        sub.setEndDate(calculateEndDate(start, normalizedPayment));
        sub.setStatus("ACTIVE");

        Double calculatedPrice = knowledgeBaseLoader.getPrice(normalizedPlan, normalizedPayment);
        sub.setPrice(calculatedPrice);
        sub.setAutoRenew(request.getAutoRenew() != null ? request.getAutoRenew() : true);
        sub.setAddress(request.getAddress());
        sub.setPreferredGenre(request.getPreferredGenre());

        Subscription saved = repository.save(sub);
        return mapToResponse(saved);
    }

    @Transactional(readOnly = true)
    public LoginResponse login(LoginRequest request) {
        Subscription sub = repository.findByUsername(request.getUsername().trim())
                .orElseThrow(() -> new UnauthorizedException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), sub.getPassword())) {
            throw new UnauthorizedException("Invalid credentials");
        }

        String token = "stream-token-" + sub.getId() + "-" + System.currentTimeMillis();
        return new LoginResponse(sub.getId(), sub.getUsername(), sub.getCustomerName(), token, "Login successful");
    }

    @Transactional(readOnly = true)
    public SubscriptionResponse getSubscription(Long id, String authUsername) {
        Subscription sub = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subscription not found with ID: " + id));

        if (authUsername != null && !authUsername.isBlank()) {
            if (!sub.getUsername().equalsIgnoreCase(authUsername.trim())) {
                throw new UnauthorizedException("Unauthorized to access another customer's subscription");
            }
        }

        return mapToResponse(sub);
    }

    public SubscriptionResponse updateSubscription(UpdateRequest request, String authUsername) {
        if (authUsername == null || authUsername.isBlank()) {
            throw new UnauthorizedException("User is not authenticated");
        }

        Subscription sub = repository.findByUsername(authUsername.trim())
                .orElseThrow(() -> new ResourceNotFoundException("Subscription not found for user: " + authUsername));

        boolean planOrPaymentChanged = false;
        String newPlan = sub.getPlanType();
        String newPayment = sub.getPaymentType();

        if (request.getCustomerName() != null && !request.getCustomerName().isBlank()) {
            sub.setCustomerName(request.getCustomerName().trim());
        }
        if (request.getMobileNumber() != null && !request.getMobileNumber().isBlank()) {
            sub.setMobileNumber(request.getMobileNumber().trim());
        }
        if (request.getAddress() != null) {
            sub.setAddress(request.getAddress().trim());
        }
        if (request.getPreferredGenre() != null) {
            sub.setPreferredGenre(request.getPreferredGenre().trim());
        }
        if (request.getPaymentMethod() != null && !request.getPaymentMethod().isBlank()) {
            sub.setPaymentMethod(request.getPaymentMethod().trim());
        }
        if (request.getAutoRenew() != null) {
            sub.setAutoRenew(request.getAutoRenew());
        }

        if (request.getPlanType() != null && !request.getPlanType().isBlank()) {
            String norm = normalizePlan(request.getPlanType());
            if (!norm.equalsIgnoreCase(sub.getPlanType())) {
                newPlan = norm;
                planOrPaymentChanged = true;
            }
        }

        if (request.getPaymentType() != null && !request.getPaymentType().isBlank()) {
            String norm = normalizePaymentType(request.getPaymentType());
            if (!norm.equalsIgnoreCase(sub.getPaymentType())) {
                newPayment = norm;
                planOrPaymentChanged = true;
            }
        }

        if (planOrPaymentChanged) {
            sub.setPlanType(newPlan);
            sub.setPaymentType(newPayment);
            // Plan change takes effect next billing cycle: extend endDate from current
            // endDate
            LocalDate currentEnd = sub.getEndDate() != null ? sub.getEndDate() : LocalDate.now();
            sub.setEndDate(calculateEndDate(currentEnd, newPayment));
            sub.setPrice(knowledgeBaseLoader.getPrice(newPlan, newPayment));
        }

        Subscription updated = repository.save(sub);
        return mapToResponse(updated);
    }

    @Transactional(readOnly = true)
    public AvailabilityResponse checkEmail(String email) {
        if (email == null || email.isBlank()) {
            return new AvailabilityResponse(false);
        }
        boolean activeExists = repository.existsByEmailIdIgnoreCaseAndStatus(email.trim(), "ACTIVE");
        return new AvailabilityResponse(!activeExists);
    }

    @Transactional(readOnly = true)
    public AvailabilityResponse checkUsername(String username) {
        if (username == null || username.isBlank()) {
            return new AvailabilityResponse(false);
        }
        boolean exists = repository.existsByUsername(username.trim());
        return new AvailabilityResponse(!exists);
    }

    private LocalDate calculateEndDate(LocalDate startDate, String paymentType) {
        String pt = paymentType.toUpperCase(Locale.ROOT);
        if (pt.contains("HALF")) {
            return startDate.plusMonths(6);
        } else if (pt.contains("ANNUAL") || pt.contains("YEAR")) {
            return startDate.plusMonths(12);
        } else if (pt.contains("QUART")) {
            return startDate.plusMonths(3);
        } else {
            return startDate.plusMonths(1);
        }
    }

    private String normalizePlan(String plan) {
        if (plan == null)
            return "STANDARD";
        String p = plan.trim().toUpperCase(Locale.ROOT);
        if (p.contains("PREMIUM"))
            return "PREMIUM";
        if (p.contains("BASIC"))
            return "BASIC";
        if (p.contains("MOBILE"))
            return "MOBILE";
        return "STANDARD";
    }

    private String normalizePaymentType(String pt) {
        if (pt == null)
            return "MONTHLY";
        String p = pt.trim().toUpperCase(Locale.ROOT);
        if (p.contains("HALF"))
            return "HALF_YEARLY";
        if (p.contains("ANNUAL") || p.contains("YEAR"))
            return "ANNUAL";
        if (p.contains("QUART"))
            return "QUARTERLY";
        return "MONTHLY";
    }

    public SubscriptionResponse mapToResponse(Subscription sub) {
        return new SubscriptionResponse(
                sub.getId(),
                sub.getCustomerName(),
                sub.getMobileNumber(),
                sub.getEmailId(),
                sub.getPlanType(),
                sub.getPaymentType(),
                sub.getStartDate(),
                sub.getEndDate(),
                sub.getStatus(),
                sub.getPaymentMethod(),
                sub.getUsername(),
                sub.getPrice(),
                sub.getAutoRenew(),
                sub.getAddress(),
                sub.getPreferredGenre());
    }
}
