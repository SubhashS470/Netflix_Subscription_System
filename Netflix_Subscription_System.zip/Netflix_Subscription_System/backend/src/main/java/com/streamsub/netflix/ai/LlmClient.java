package com.streamsub.netflix.ai;

import com.streamsub.netflix.dto.AiResponse;

public interface LlmClient {
    AiResponse generateResponse(String userQuery);
}
