package com.streamsub.netflix.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.streamsub.netflix.dto.SubscriptionResponse;
import com.streamsub.netflix.dto.UpdateRequest;
import com.streamsub.netflix.service.KnowledgeBaseLoader;
import com.streamsub.netflix.service.SubscriptionService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/subscription")
@CrossOrigin(origins = "*")
public class SubscriptionController {

    private final SubscriptionService subscriptionService;
    private final KnowledgeBaseLoader knowledgeBaseLoader;

    public SubscriptionController(SubscriptionService subscriptionService,
            KnowledgeBaseLoader knowledgeBaseLoader) {
        this.subscriptionService = subscriptionService;
        this.knowledgeBaseLoader = knowledgeBaseLoader;
    }

    @GetMapping("/{id}")
    public ResponseEntity<SubscriptionResponse> getSubscription(
            @PathVariable("id") Long id,
            @RequestHeader(value = "X-Auth-User", required = false) String authUserHeader,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {

        String effectiveUser = extractUsername(authUserHeader, authHeader);
        SubscriptionResponse response = subscriptionService.getSubscription(id, effectiveUser);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/update")
    public ResponseEntity<SubscriptionResponse> updateSubscription(
            @Valid @RequestBody UpdateRequest request,
            @RequestHeader(value = "X-Auth-User", required = false) String authUserHeader,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {

        String effectiveUser = extractUsername(authUserHeader, authHeader);
        SubscriptionResponse response = subscriptionService.updateSubscription(request, effectiveUser);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/plans")
    public ResponseEntity<JsonNode> getPlans() {
        return ResponseEntity.ok(knowledgeBaseLoader.getSubscriptionPlans());
    }

    private String extractUsername(String authUserHeader, String authHeader) {
        if (authUserHeader != null && !authUserHeader.isBlank()) {
            return authUserHeader.trim();
        }
        if (authHeader != null && !authHeader.isBlank()) {
            String token = authHeader.replace("Bearer ", "").trim();
            // Tokens formatted like stream-token-{id}-{timestamp} or standard username
            // token
            if (token.contains(":")) {
                return token.split(":")[0];
            }
            return token;
        }
        return null;
    }
}
