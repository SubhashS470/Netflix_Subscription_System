package com.streamsub.netflix.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AiResponse {

    private String type; // "content" or "policy"
    private List<String> titles;
    private List<String> genre;
    private String reason;
    private List<Double> rating;
    private String answer;
    private String source_section;

    public AiResponse() {
    }

    public static AiResponse content(List<String> titles, List<String> genre, String reason, List<Double> rating) {
        AiResponse res = new AiResponse();
        res.setType("content");
        res.setTitles(titles);
        res.setGenre(genre);
        res.setReason(reason);
        res.setRating(rating);
        return res;
    }

    public static AiResponse policy(String answer, String source_section) {
        AiResponse res = new AiResponse();
        res.setType("policy");
        res.setAnswer(answer);
        res.setSource_section(source_section);
        return res;
    }

    public static AiResponse fallback(String supportInfo) {
        AiResponse res = new AiResponse();
        res.setType("policy");
        res.setAnswer(
                "I couldn't match this query with our streaming catalog or subscription policies. " + supportInfo);
        res.setSource_section("support_information");
        return res;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getTitles() {
        return titles;
    }

    public void setTitles(List<String> titles) {
        this.titles = titles;
    }

    public List<String> getGenre() {
        return genre;
    }

    public void setGenre(List<String> genre) {
        this.genre = genre;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public List<Double> getRating() {
        return rating;
    }

    public void setRating(List<Double> rating) {
        this.rating = rating;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getSource_section() {
        return source_section;
    }

    public void setSource_section(String source_section) {
        this.source_section = source_section;
    }
}
