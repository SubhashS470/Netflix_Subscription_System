package com.streamsub.netflix.controller;

import com.streamsub.netflix.ai.LlmClient;
import com.streamsub.netflix.dto.AiRequest;
import com.streamsub.netflix.dto.AiResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin(origins = "*")
public class AiController {

    private final LlmClient llmClient;

    public AiController(LlmClient llmClient) {
        this.llmClient = llmClient;
    }

    @PostMapping("/recommend")
    public ResponseEntity<AiResponse> recommend(@Valid @RequestBody AiRequest request) {
        if (request.getQuery() == null || request.getQuery().trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        AiResponse response = llmClient.generateResponse(request.getQuery().trim());
        return ResponseEntity.ok(response);
    }
}
