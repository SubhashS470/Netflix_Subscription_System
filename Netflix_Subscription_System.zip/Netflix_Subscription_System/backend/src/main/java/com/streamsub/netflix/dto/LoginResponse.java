package com.streamsub.netflix.dto;

public class LoginResponse {

    private Long subscriptionId;
    private String username;
    private String customerName;
    private String token;
    private String message;

    public LoginResponse() {
    }

    public LoginResponse(Long subscriptionId, String username, String customerName, String token, String message) {
        this.subscriptionId = subscriptionId;
        this.username = username;
        this.customerName = customerName;
        this.token = token;
        this.message = message;
    }

    public Long getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(Long subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
