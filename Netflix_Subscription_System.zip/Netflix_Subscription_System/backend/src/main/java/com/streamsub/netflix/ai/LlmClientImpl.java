package com.streamsub.netflix.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.streamsub.netflix.dto.AiResponse;
import com.streamsub.netflix.service.KnowledgeBaseLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.time.Duration;
import java.util.*;

@Service
public class LlmClientImpl implements LlmClient {

    private static final Logger log = LoggerFactory.getLogger(LlmClientImpl.class);

    private final PromptBuilder promptBuilder;
    private final KnowledgeBaseLoader knowledgeBaseLoader;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${llm.api-key:}")
    private String apiKey;

    @Value("${llm.base-url:https://llmgateway-cognizant-assessment.tekstac.com/v1}")
    private String baseUrl;

    @Value("${llm.model:claude-3-haiku-20240307}")
    private String modelName;

    public LlmClientImpl(PromptBuilder promptBuilder,
            KnowledgeBaseLoader knowledgeBaseLoader,
            RestTemplateBuilder restTemplateBuilder) {
        this.promptBuilder = promptBuilder;
        this.knowledgeBaseLoader = knowledgeBaseLoader;
        this.restTemplate = restTemplateBuilder
                .setConnectTimeout(Duration.ofSeconds(10))
                .setReadTimeout(Duration.ofSeconds(30))
                .build();
    }

    @Override
    public AiResponse generateResponse(String userQuery) {
        String systemPrompt = promptBuilder.buildSystemPrompt();
        String userPrompt = promptBuilder.buildUserPrompt(userQuery);

        // Normalize base URL
        String url = baseUrl != null ? baseUrl.trim() : "https://llmgateway-cognizant-assessment.tekstac.com/v1";
        if (url.endsWith("/")) {
            url = url.substring(0, url.length() - 1);
        }
        String endpoint = url + "/chat/completions";

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", modelName);
        requestBody.put("temperature", 0.2);
        requestBody.put("max_tokens", 1000);

        List<Map<String, String>> messages = new ArrayList<>();
        Map<String, String> sysMsg = new HashMap<>();
        sysMsg.put("role", "system");
        sysMsg.put("content", systemPrompt);
        messages.add(sysMsg);

        Map<String, String> usrMsg = new HashMap<>();
        usrMsg.put("role", "user");
        usrMsg.put("content", userPrompt);
        messages.add(usrMsg);

        requestBody.put("messages", messages);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (apiKey != null && !apiKey.isBlank()) {
            headers.setBearerAuth(apiKey.trim());
        }

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(endpoint, entity, String.class);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return parseLlmResponse(response.getBody());
            } else {
                throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "LLM returned non-200 status code");
            }
        } catch (ResourceAccessException e) {
            log.error("LLM Gateway timeout: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.GATEWAY_TIMEOUT, "LLM Gateway timed out");
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("LLM Gateway error: {} {}", e.getStatusCode(), e.getMessage());
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY,
                    "LLM Gateway communication failure: " + e.getStatusCode());
        } catch (Exception e) {
            log.error("Error communicating with LLM: {}", e.getMessage());
            // Fallback response referencing support information
            return AiResponse.fallback(knowledgeBaseLoader.getSupportInformation());
        }
    }

    public AiResponse parseLlmResponse(String responseJson) {
        try {
            JsonNode root = objectMapper.readTree(responseJson);
            JsonNode choices = root.get("choices");
            if (choices != null && choices.isArray() && !choices.isEmpty()) {
                JsonNode message = choices.get(0).get("message");
                if (message != null && message.has("content")) {
                    String content = message.get("content").asText("");
                    return parseContentJson(content);
                }
            }
        } catch (Exception e) {
            log.warn("Failed to parse LLM response wrapper: {}", e.getMessage());
        }
        return AiResponse.fallback(knowledgeBaseLoader.getSupportInformation());
    }

    public AiResponse parseContentJson(String rawContent) {
        if (rawContent == null || rawContent.isBlank()) {
            return AiResponse.fallback(knowledgeBaseLoader.getSupportInformation());
        }

        // Clean any code block fences
        String cleaned = rawContent.trim();
        if (cleaned.startsWith("```json")) {
            cleaned = cleaned.substring(7);
        } else if (cleaned.startsWith("```")) {
            cleaned = cleaned.substring(3);
        }
        if (cleaned.endsWith("```")) {
            cleaned = cleaned.substring(0, cleaned.length() - 3);
        }
        cleaned = cleaned.trim();

        try {
            JsonNode node = objectMapper.readTree(cleaned);
            String type = node.path("type").asText("policy");

            if ("content".equalsIgnoreCase(type)) {
                List<String> titles = new ArrayList<>();
                if (node.has("titles")) {
                    for (JsonNode t : node.get("titles")) {
                        titles.add(t.asText());
                    }
                }
                List<String> genres = new ArrayList<>();
                if (node.has("genre")) {
                    for (JsonNode g : node.get("genre")) {
                        genres.add(g.asText());
                    }
                }
                String reason = node.path("reason").asText("");
                List<Double> ratings = new ArrayList<>();
                if (node.has("rating")) {
                    for (JsonNode r : node.get("rating")) {
                        ratings.add(r.asDouble());
                    }
                }
                return AiResponse.content(titles, genres, reason, ratings);
            } else {
                String answer = node.path("answer").asText("");
                String sourceSection = node.path("source_section").asText("policies");
                if (answer.isBlank()) {
                    return AiResponse.fallback(knowledgeBaseLoader.getSupportInformation());
                }
                return AiResponse.policy(answer, sourceSection);
            }
        } catch (Exception e) {
            log.warn("Failed to parse LLM structured json: {}", e.getMessage());
            return AiResponse.fallback(knowledgeBaseLoader.getSupportInformation());
        }
    }
}
