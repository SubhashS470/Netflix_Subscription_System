package com.streamsub.netflix.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.Locale;

@Service
public class KnowledgeBaseLoader {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private JsonNode rootNode;
    private String rawJsonString;

    @PostConstruct
    public void init() {
        try {
            ClassPathResource resource = new ClassPathResource("streamingservice_knowledge_base.json");
            try (InputStream inputStream = resource.getInputStream()) {
                rootNode = objectMapper.readTree(inputStream);
                rawJsonString = objectMapper.writeValueAsString(rootNode);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to load streamingservice_knowledge_base.json", e);
        }
    }

    public JsonNode getRootNode() {
        return rootNode;
    }

    public String getRawJsonString() {
        return rawJsonString;
    }

    public JsonNode getContentCatalog() {
        return rootNode != null ? rootNode.get("content_catalog") : null;
    }

    public JsonNode getSubscriptionPlans() {
        return rootNode != null ? rootNode.get("subscription_plans") : null;
    }

    public JsonNode getPolicies() {
        return rootNode != null ? rootNode.get("policies") : null;
    }

    public JsonNode getFaqs() {
        return rootNode != null ? rootNode.get("faqs") : null;
    }

    public String getSupportInformation() {
        if (rootNode != null && rootNode.has("policies") && rootNode.get("policies").has("support_information")) {
            return rootNode.get("policies").get("support_information").asText();
        }
        return "Please contact StreamSub customer support at support@streamsub.com or 1-800-STREAM-SUB.";
    }

    public Double getPrice(String planType, String paymentType) {
        if (rootNode == null || !rootNode.has("subscription_plans")) {
            return 199.0;
        }

        String normalizedPaymentKey = normalizePaymentKey(paymentType);
        for (JsonNode plan : rootNode.get("subscription_plans")) {
            String planName = plan.path("plan_name").asText("");
            if (planName.equalsIgnoreCase(planType)) {
                JsonNode pricing = plan.get("pricing");
                if (pricing != null && pricing.has(normalizedPaymentKey)) {
                    return pricing.get(normalizedPaymentKey).asDouble();
                }
            }
        }
        return 199.0;
    }

    private String normalizePaymentKey(String paymentType) {
        if (paymentType == null)
            return "monthly";
        String lower = paymentType.toLowerCase(Locale.ROOT).replace("-", "_").replace(" ", "_");
        if (lower.contains("annual") || lower.contains("year"))
            return "annual";
        if (lower.contains("half"))
            return "half_yearly";
        if (lower.contains("quart"))
            return "quarterly";
        return "monthly";
    }
}
