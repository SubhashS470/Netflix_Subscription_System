package com.streamsub.netflix.controller;

import com.streamsub.netflix.dto.AvailabilityResponse;
import com.streamsub.netflix.dto.LoginRequest;
import com.streamsub.netflix.dto.LoginResponse;
import com.streamsub.netflix.dto.RegisterRequest;
import com.streamsub.netflix.dto.SubscriptionResponse;
import com.streamsub.netflix.service.SubscriptionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final SubscriptionService subscriptionService;

    public AuthController(SubscriptionService subscriptionService) {
        this.subscriptionService = subscriptionService;
    }

    @PostMapping("/register")
    public ResponseEntity<SubscriptionResponse> register(@Valid @RequestBody RegisterRequest request) {
        SubscriptionResponse response = subscriptionService.register(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        LoginResponse response = subscriptionService.login(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/check-email")
    public ResponseEntity<AvailabilityResponse> checkEmail(@RequestParam("email") String email) {
        return ResponseEntity.ok(subscriptionService.checkEmail(email));
    }

    @GetMapping("/check-username")
    public ResponseEntity<AvailabilityResponse> checkUsername(@RequestParam("username") String username) {
        return ResponseEntity.ok(subscriptionService.checkUsername(username));
    }
}
