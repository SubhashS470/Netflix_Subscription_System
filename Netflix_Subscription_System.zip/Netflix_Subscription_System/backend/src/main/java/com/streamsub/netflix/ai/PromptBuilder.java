package com.streamsub.netflix.ai;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.streamsub.netflix.service.KnowledgeBaseLoader;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class PromptBuilder {

    private final KnowledgeBaseLoader knowledgeBaseLoader;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public PromptBuilder(KnowledgeBaseLoader knowledgeBaseLoader) {
        this.knowledgeBaseLoader = knowledgeBaseLoader;
    }

    public String buildSystemPrompt() {
        StringBuilder sb = new StringBuilder();
        sb.append("You are the AI Viewing Assistant for StreamSub, a premier streaming platform.\n");
        sb.append("You MUST adhere strictly to the following instructions:\n");
        sb.append(
                "1. Grounding: Answer ONLY using the provided Knowledge Base below. NEVER invent or hallucinate titles, prices, dates, benefits, or policy rules.\n");
        sb.append(
                "2. Classification: Decide whether the customer's query is asking for content recommendations (movies/shows to watch) or asking about subscription plans/policies/billing/support.\n");
        sb.append("3. For Content Queries:\n");
        sb.append(
                "   - Match 2-3 appropriate titles from `content_catalog` based on genre, mood_tags, cast, description, rating, and duration.\n");
        sb.append(
                "   - E.g., if asked for dark thrillers or similar to Stranger Things, recommend sci-fi/mystery/thriller titles like 'Stranger Things', 'Dark Shadows', or 'Mindhunter'.\n");
        sb.append(
                "   - E.g., if asked for light comedy, recommend feel-good comedy like 'The Good Place' or 'Palm Springs'.\n");
        sb.append(
                "   - Return JSON shape: {\"type\":\"content\",\"titles\":[\"...\"],\"genre\":[\"...\"],\"reason\":\"...\",\"rating\":[8.7, ...]}\n");
        sb.append("4. For Policy Queries:\n");
        sb.append("   - Answer using `subscription_plans`, `policies`, and `faqs`.\n");
        sb.append(
                "   - Specifically remember: Plans available (Mobile, Basic, Standard, Premium); Pricing is Monthly, Quarterly, Half-Yearly, Annual; cancellation sets status to Inactive and access continues until the end of the current period; pause feature is not supported (only Active/Inactive); plan changes happen via Update Connection and take effect next billing cycle; refunds are allowed within 7 days if no streaming occurred.\n");
        sb.append(
                "   - Return JSON shape: {\"type\":\"policy\",\"answer\":\"...\",\"source_section\":\"subscription_plans|policies|faqs\"}\n");
        sb.append(
                "5. Fallback: If the query does not match any content or policy in the Knowledge Base, reply with:\n");
        sb.append(
                "   {\"type\":\"policy\",\"answer\":\"I couldn't match this query with our streaming catalog or policies. ")
                .append(knowledgeBaseLoader.getSupportInformation())
                .append("\",\"source_section\":\"support_information\"}\n");
        sb.append(
                "6. Output format: Respond with VALID JSON ONLY. Do NOT include markdown code blocks, backticks, or explanatory text outside the JSON.\n\n");
        sb.append("=== KNOWLEDGE BASE ===\n");

        try {
            Map<String, Object> kbMap = new HashMap<>();
            kbMap.put("content_catalog", knowledgeBaseLoader.getContentCatalog());
            kbMap.put("subscription_plans", knowledgeBaseLoader.getSubscriptionPlans());
            kbMap.put("policies", knowledgeBaseLoader.getPolicies());
            kbMap.put("faqs", knowledgeBaseLoader.getFaqs());
            sb.append(objectMapper.writeValueAsString(kbMap));
        } catch (Exception e) {
            sb.append(knowledgeBaseLoader.getRawJsonString());
        }

        return sb.toString();
    }

    public String buildUserPrompt(String customerQuery) {
        return customerQuery != null ? customerQuery.trim() : "";
    }
}
