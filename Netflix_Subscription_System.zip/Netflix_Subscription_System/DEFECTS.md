# StreamSub System - Defect Log and Resolutions

This document catalogs the defects identified during the audit and implementation of the StreamSub Subscription & Viewing Assistant system, along with the precise resolutions applied.

---

### Defect 1: Plaintext Password Storage and Leaking in Responses
- **Symptom / Risk**: Passwords stored without hashing or returned in API responses violate privacy and security standards.
- **Root Cause**: Plaintext strings assigned to entity without BCrypt encoding; entity returned directly in controller responses.
- **Resolution**:
  - Configured `BCryptPasswordEncoder` bean in `StreamSubApplication`.
  - Passwords are encrypted before saving via `passwordEncoder.encode(rawPassword)`.
  - Created `SubscriptionResponse` DTO that strictly excludes the `password` field from all API responses (`/register`, `/subscription/{id}`, `/subscription/update`).

---

### Defect 2: Duplicate Active Email Check Ignoring Prior Inactive Subscriptions
- **Symptom / Risk**: Returning 409 Conflict when a returning customer with prior expired or `INACTIVE` subscriptions attempts to register.
- **Root Cause**: Query only checked `existsByEmailId`, blocking legitimate re-subscriptions.
- **Resolution**:
  - Implemented `findByEmailIdIgnoreCase(email)` and inspected subscription statuses.
  - Returns `409 Conflict` only if any existing subscription has `status = "ACTIVE"`.
  - If all prior subscriptions are `INACTIVE`, new registration is permitted and activated.

---

### Defect 3: Duplicate Username Check Condition Flaw
- **Symptom / Risk**: Username collision allowed if an existing account had inactive status.
- **Root Cause**: Username uniqueness logic improperly coupled with active status.
- **Resolution**:
  - Implemented global check `existsByUsername(username)` regardless of status.
  - Returns `409 Conflict` for any duplicate username across the entire platform.

---

### Defect 4: Ambiguous Failed Login Status and Error Messaging
- **Symptom / Risk**: Returning `403 Forbidden` or specific messages revealing whether the username or password was incorrect allows user enumeration.
- **Root Cause**: Different error responses for unknown user vs. incorrect password.
- **Resolution**:
  - Unified failed login response to HTTP `401 Unauthorized` with generic message `"Invalid credentials"` for both unknown username and invalid password.

---

### Defect 5: Payment Type Calculation Clashing on "HALF_YEARLY" and "YEAR"
- **Symptom / Risk**: `HALF_YEARLY` payment type incorrectly matched `contains("YEAR")`, calculating 12 months instead of 6 months.
- **Root Cause**: Evaluation order checked `ANNUAL || YEAR` before checking `HALF`.
- **Resolution**:
  - Evaluated `HALF` check before `YEAR`/`ANNUAL` check in both `calculateEndDate` and `normalizePaymentType`.
  - Unit tests verify all 4 plans × 4 payment cycles (+1, +3, +6, +12 months).

---

### Defect 6: Missing 404 Route on Frontend
- **Symptom / Risk**: Navigating to unmapped routes resulted in a blank screen.
- **Root Cause**: React Router lacked a catch-all wildcard `*` route.
- **Resolution**:
  - Created `NotFoundPage.jsx` displaying a styled 404 error and navigation link back to the Dashboard.
  - Registered `<Route path="*" element={<NotFoundPage />} />`.

---

### Defect 7: Inadequate AI Assistant Response Parsing & Unsafe Fallbacks
- **Symptom / Risk**: If LLM returned markdown code blocks or invalid JSON, API returned 500 errors.
- **Root Cause**: Raw string handling without stripping markdown fences or extracting grounded JSON objects.
- **Resolution**:
  - Built `LlmClientImpl` with markdown code block stripping (` ```json `, ` ``` `).
  - Implemented structured fallbacks referencing `policies.support_information`.
  - Mapped gateway network errors to HTTP `502 Bad Gateway` and timeouts to HTTP `504 Gateway Timeout`.
