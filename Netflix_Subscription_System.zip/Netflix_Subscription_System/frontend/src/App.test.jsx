import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import App from "./App";

describe("StreamSub Frontend Navigation & Pages", () => {
  beforeEach(() => {
    localStorage.clear();
  });

  test("renders Navbar and brand logo", () => {
    render(<App />);
    const logo = screen.getByTestId("brand-logo");
    expect(logo).toBeInTheDocument();
    expect(logo).toHaveTextContent("StreamSub");
  });

  test("renders login link when logged out", () => {
    render(<App />);
    const loginLink = screen.getByTestId("nav-login");
    expect(loginLink).toBeInTheDocument();
  });
});
