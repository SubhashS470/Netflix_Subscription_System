import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

const PLAN_DATA = [
  {
    name: "Mobile",
    quality: "480p (Standard definition)",
    screens: 1,
    downloads: 1,
    pricing: { Monthly: 149, Quarterly: 419, "Half-Yearly": 799, Annual: 1499 },
  },
  {
    name: "Basic",
    quality: "720p (HD)",
    screens: 1,
    downloads: 1,
    pricing: {
      Monthly: 199,
      Quarterly: 559,
      "Half-Yearly": 1069,
      Annual: 1999,
    },
  },
  {
    name: "Standard",
    quality: "1080p (Full HD)",
    screens: 2,
    downloads: 2,
    pricing: {
      Monthly: 499,
      Quarterly: 1399,
      "Half-Yearly": 2699,
      Annual: 4999,
    },
  },
  {
    name: "Premium",
    quality: "4K + HDR (Ultra HD)",
    screens: 4,
    downloads: 6,
    pricing: {
      Monthly: 649,
      Quarterly: 1819,
      "Half-Yearly": 3499,
      Annual: 6499,
    },
  },
];

export default function ApplyPage() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    customerName: "",
    mobileNumber: "",
    emailId: "",
    username: "",
    password: "",
    confirmPassword: "",
    planType: "",
    paymentType: "Monthly",
    paymentMethod: "Credit Card",
    address: "",
    preferredGenre: "",
    autoRenew: true,
  });

  const [errors, setErrors] = useState({});
  const [emailStatus, setEmailStatus] = useState(null); // { available, message }
  const [usernameStatus, setUsernameStatus] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [serverError, setServerError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Validate single field on change to immediately clear errors
  const validateField = (name, value) => {
    let err = "";
    if (name === "customerName") {
      if (!value.trim()) {
        err = "Customer name is required";
      } else if (!/^[a-zA-Z\s]{3,}$/.test(value.trim())) {
        err =
          "Name must be at least 3 characters and contain only letters and spaces";
      }
    } else if (name === "mobileNumber") {
      if (!value.trim()) {
        err = "Mobile number is required";
      } else if (!/^\d{10}$/.test(value.trim())) {
        err = "Mobile number must be exactly 10 digits";
      }
    } else if (name === "emailId") {
      if (!value.trim()) {
        err = "Email is required";
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())) {
        err = "Invalid email format";
      }
    } else if (name === "username") {
      if (!value.trim()) {
        err = "Username is required";
      }
    } else if (name === "password") {
      if (!value) {
        err = "Password is required";
      } else if (
        !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$/.test(
          value,
        )
      ) {
        err =
          "Password must be at least 8 characters with uppercase, lowercase, digit, and special character";
      }
    } else if (name === "confirmPassword") {
      if (!value) {
        err = "Confirm password is required";
      } else if (value !== formData.password) {
        err = "Passwords do not match";
      }
    } else if (name === "planType") {
      if (!value) err = "Please select a subscription plan";
    } else if (name === "paymentType") {
      if (!value) err = "Please select a payment type";
    }
    return err;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const val = type === "checkbox" ? checked : value;

    setFormData((prev) => ({ ...prev, [name]: val }));
    setServerError("");

    // Clear and re-validate field
    const fieldError = validateField(name, val);
    setErrors((prev) => ({ ...prev, [name]: fieldError }));

    if (name === "emailId") {
      setEmailStatus(null);
    }
    if (name === "username") {
      setUsernameStatus(null);
    }
  };

  // Async email check on blur
  const handleEmailBlur = async () => {
    if (!formData.emailId || errors.emailId) return;
    try {
      const res = await fetch(
        `/api/auth/check-email?email=${encodeURIComponent(formData.emailId.trim())}`,
      );
      if (res.ok) {
        const data = await res.json();
        if (data.available) {
          setEmailStatus({ available: true, message: "email is available" });
        } else {
          setEmailStatus({
            available: false,
            message: "An active subscription already exists for this email",
          });
          setErrors((prev) => ({
            ...prev,
            emailId: "An active subscription already exists for this email",
          }));
        }
      }
    } catch (err) {
      // ignore network errors on blur
    }
  };

  // Async username check on blur
  const handleUsernameBlur = async () => {
    if (!formData.username || errors.username) return;
    try {
      const res = await fetch(
        `/api/auth/check-username?username=${encodeURIComponent(formData.username.trim())}`,
      );
      if (res.ok) {
        const data = await res.json();
        if (data.available) {
          setUsernameStatus({
            available: true,
            message: "username is available",
          });
        } else {
          setUsernameStatus({
            available: false,
            message: "Username is already taken",
          });
          setErrors((prev) => ({
            ...prev,
            username: "Username is already taken",
          }));
        }
      }
    } catch (err) {
      // ignore
    }
  };

  const handleReset = () => {
    setFormData({
      customerName: "",
      mobileNumber: "",
      emailId: "",
      username: "",
      password: "",
      confirmPassword: "",
      planType: "",
      paymentType: "Monthly",
      paymentMethod: "Credit Card",
      address: "",
      preferredGenre: "",
      autoRenew: true,
    });
    setErrors({});
    setEmailStatus(null);
    setUsernameStatus(null);
    setServerError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate all fields
    const newErrors = {};
    [
      "customerName",
      "mobileNumber",
      "emailId",
      "username",
      "password",
      "confirmPassword",
      "planType",
      "paymentType",
    ].forEach((field) => {
      const err = validateField(field, formData[field]);
      if (err) newErrors[field] = err;
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setSubmitting(true);
    setServerError("");

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: formData.customerName.trim(),
          mobileNumber: formData.mobileNumber.trim(),
          emailId: formData.emailId.trim(),
          username: formData.username.trim(),
          password: formData.password,
          confirmPassword: formData.confirmPassword,
          planType: formData.planType,
          paymentType: formData.paymentType,
          paymentMethod: formData.paymentMethod,
          address: formData.address,
          preferredGenre: formData.preferredGenre,
          autoRenew: formData.autoRenew,
        }),
      });

      if (res.status === 201) {
        navigate("/login", {
          state: { message: "Registration successful! Please log in." },
        });
      } else if (res.status === 409) {
        const data = await res.json();
        setServerError(
          data.message || "An active subscription or username already exists",
        );
      } else {
        const data = await res.json().catch(() => ({}));
        setServerError(
          data.message || "Registration failed. Please check your inputs.",
        );
      }
    } catch (err) {
      setServerError("Connection error. Please try again later.");
    } finally {
      setSubmitting(false);
    }
  };

  const isSubmitDisabled =
    !formData.planType || !formData.paymentType || submitting;

  return (
    <div className="container" data-testid="apply-page">
      <div className="form-card">
        <h1 className="form-title">Start Your StreamSub Connection</h1>
        <p className="form-subtitle">
          Choose a plan, create your login, and enjoy unlimited streaming. Have
          questions?{" "}
          <Link to="/ai-assistant" data-testid="link-assistant-prompt">
            Ask our AI Viewing Assistant
          </Link>
        </p>

        {serverError && (
          <div className="central-error" data-testid="server-error-msg">
            ⚠️ {serverError}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          {/* Full Name */}
          <div className="form-group">
            <label htmlFor="customerName">
              Full Name <span className="required">*</span>
            </label>
            <input
              id="customerName"
              name="customerName"
              type="text"
              className="form-control"
              placeholder="e.g. John Doe"
              value={formData.customerName}
              onChange={handleChange}
              data-testid="input-customer-name"
            />
            {errors.customerName && (
              <span className="error-text" data-testid="error-customer-name">
                {errors.customerName}
              </span>
            )}
          </div>

          {/* Mobile */}
          <div className="form-group">
            <label htmlFor="mobileNumber">
              Mobile Number <span className="required">*</span>
            </label>
            <input
              id="mobileNumber"
              name="mobileNumber"
              type="text"
              inputMode="numeric"
              maxLength={10}
              className="form-control"
              placeholder="10-digit mobile number"
              value={formData.mobileNumber}
              onChange={handleChange}
              data-testid="input-mobile-number"
            />
            {errors.mobileNumber && (
              <span className="error-text" data-testid="error-mobile-number">
                {errors.mobileNumber}
              </span>
            )}
          </div>

          {/* Email */}
          <div className="form-group">
            <label htmlFor="emailId">
              Email Address <span className="required">*</span>
            </label>
            <input
              id="emailId"
              name="emailId"
              type="email"
              className="form-control"
              placeholder="name@example.com"
              value={formData.emailId}
              onChange={handleChange}
              onBlur={handleEmailBlur}
              data-testid="input-email"
            />
            {errors.emailId && (
              <span className="error-text" data-testid="error-email">
                {errors.emailId}
              </span>
            )}
            {!errors.emailId && emailStatus && (
              <span
                className={
                  emailStatus.available ? "success-text" : "error-text"
                }
                data-testid="status-email"
              >
                {emailStatus.available
                  ? "✓ email is available"
                  : `✗ ${emailStatus.message}`}
              </span>
            )}
          </div>

          {/* Username */}
          <div className="form-group">
            <label htmlFor="username">
              Username <span className="required">*</span>
            </label>
            <input
              id="username"
              name="username"
              type="text"
              className="form-control"
              placeholder="Choose a unique username"
              value={formData.username}
              onChange={handleChange}
              onBlur={handleUsernameBlur}
              data-testid="input-username"
            />
            {errors.username && (
              <span className="error-text" data-testid="error-username">
                {errors.username}
              </span>
            )}
            {!errors.username && usernameStatus && (
              <span
                className={
                  usernameStatus.available ? "success-text" : "error-text"
                }
                data-testid="status-username"
              >
                {usernameStatus.available
                  ? "✓ username is available"
                  : `✗ ${usernameStatus.message}`}
              </span>
            )}
          </div>

          {/* Password */}
          <div className="form-group">
            <label htmlFor="password">
              Password <span className="required">*</span>
            </label>
            <div className="password-wrapper">
              <input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                className="form-control"
                placeholder="At least 8 chars with upper, lower, digit & special"
                value={formData.password}
                onChange={handleChange}
                data-testid="input-password"
              />
              <button
                type="button"
                className="eye-btn"
                onClick={() => setShowPassword(!showPassword)}
                data-testid="toggle-password-btn"
                aria-label="Toggle password visibility"
              >
                {showPassword ? "👁️" : "🙈"}
              </button>
            </div>
            {errors.password && (
              <span className="error-text" data-testid="error-password">
                {errors.password}
              </span>
            )}
          </div>

          {/* Confirm Password */}
          <div className="form-group">
            <label htmlFor="confirmPassword">
              Confirm Password <span className="required">*</span>
            </label>
            <div className="password-wrapper">
              <input
                id="confirmPassword"
                name="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                className="form-control"
                placeholder="Re-enter password"
                value={formData.confirmPassword}
                onChange={handleChange}
                data-testid="input-confirm-password"
              />
              <button
                type="button"
                className="eye-btn"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                data-testid="toggle-confirm-password-btn"
                aria-label="Toggle confirm password visibility"
              >
                {showConfirmPassword ? "👁️" : "🙈"}
              </button>
            </div>
            {errors.confirmPassword && (
              <span className="error-text" data-testid="error-confirm-password">
                {errors.confirmPassword}
              </span>
            )}
          </div>

          {/* Payment Type Selector */}
          <div className="form-group">
            <label htmlFor="paymentType">
              Payment Type / Billing Cycle <span className="required">*</span>
            </label>
            <select
              id="paymentType"
              name="paymentType"
              className="form-control"
              value={formData.paymentType}
              onChange={handleChange}
              data-testid="select-payment-type"
            >
              <option value="Monthly">Monthly (+1 Month)</option>
              <option value="Quarterly">Quarterly (+3 Months)</option>
              <option value="Half-Yearly">Half-Yearly (+6 Months)</option>
              <option value="Annual">Annual (+12 Months)</option>
            </select>
            {errors.paymentType && (
              <span className="error-text" data-testid="error-payment-type">
                {errors.paymentType}
              </span>
            )}
          </div>

          {/* Plan Selection Cards */}
          <div className="form-group">
            <label>
              Choose a Plan <span className="required">*</span>
            </label>
            <div className="plan-grid" data-testid="plan-cards-grid">
              {PLAN_DATA.map((plan) => {
                const isSelected =
                  formData.planType.toUpperCase() === plan.name.toUpperCase();
                const price =
                  plan.pricing[formData.paymentType] || plan.pricing["Monthly"];
                return (
                  <div
                    key={plan.name}
                    className={`plan-card ${isSelected ? "selected" : ""}`}
                    onClick={() => {
                      setFormData((prev) => ({ ...prev, planType: plan.name }));
                      setErrors((prev) => ({ ...prev, planType: "" }));
                    }}
                    data-testid={`plan-card-${plan.name.toLowerCase()}`}
                  >
                    <div className="plan-card-name">{plan.name}</div>
                    <div
                      className="plan-card-price"
                      data-testid={`plan-price-${plan.name.toLowerCase()}`}
                    >
                      ₹{price}
                      <span
                        style={{
                          fontSize: "0.8rem",
                          color: "#AAAAAA",
                          fontWeight: "normal",
                        }}
                      >
                        /{formData.paymentType.toLowerCase()}
                      </span>
                    </div>
                    <ul className="plan-card-features">
                      <li>📺 Video: {plan.quality}</li>
                      <li>👥 Screens: {plan.screens}</li>
                      <li>📥 Downloads: {plan.downloads} devices</li>
                    </ul>
                  </div>
                );
              })}
            </div>
            {errors.planType && (
              <span className="error-text" data-testid="error-plan-type">
                {errors.planType}
              </span>
            )}
          </div>

          {/* Payment Method */}
          <div className="form-group">
            <label htmlFor="paymentMethod">
              Payment Method <span className="required">*</span>
            </label>
            <select
              id="paymentMethod"
              name="paymentMethod"
              className="form-control"
              value={formData.paymentMethod}
              onChange={handleChange}
              data-testid="select-payment-method"
            >
              <option value="Credit Card">Credit Card</option>
              <option value="Debit Card">Debit Card</option>
              <option value="UPI">UPI (Google Pay, PhonePe, Paytm)</option>
              <option value="Net Banking">Net Banking</option>
              <option value="PayPal">PayPal</option>
            </select>
          </div>

          {/* Optional Address */}
          <div className="form-group">
            <label htmlFor="address">Address (Optional)</label>
            <input
              id="address"
              name="address"
              type="text"
              className="form-control"
              placeholder="e.g. 123 Main Street"
              value={formData.address}
              onChange={handleChange}
              data-testid="input-address"
            />
          </div>

          {/* Optional Preferred Genre */}
          <div className="form-group">
            <label htmlFor="preferredGenre">Preferred Genre (Optional)</label>
            <input
              id="preferredGenre"
              name="preferredGenre"
              type="text"
              className="form-control"
              placeholder="e.g. Sci-Fi, Thriller, Comedy"
              value={formData.preferredGenre}
              onChange={handleChange}
              data-testid="input-preferred-genre"
            />
          </div>

          {/* Auto-renew */}
          <div
            className="form-group"
            style={{ flexDirection: "row", alignItems: "center", gap: "10px" }}
          >
            <input
              id="autoRenew"
              name="autoRenew"
              type="checkbox"
              checked={formData.autoRenew}
              onChange={handleChange}
              data-testid="checkbox-auto-renew"
            />
            <label
              htmlFor="autoRenew"
              style={{ margin: 0, fontWeight: "normal", cursor: "pointer" }}
            >
              Enable automatic renewal at each billing cycle
            </label>
          </div>

          {/* Action Buttons */}
          <div style={{ display: "flex", gap: "16px", marginTop: "24px" }}>
            <button
              type="submit"
              className="btn-primary"
              disabled={isSubmitDisabled}
              data-testid="btn-create-account"
            >
              {submitting ? "Creating account..." : "Create account"}
            </button>
            <button
              type="button"
              className="btn-secondary"
              onClick={handleReset}
              data-testid="btn-reset"
            >
              Reset
            </button>
          </div>

          <div style={{ marginTop: "20px", color: "#AAAAAA" }}>
            Already have an account?{" "}
            <Link to="/login" data-testid="link-login">
              Log in
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
