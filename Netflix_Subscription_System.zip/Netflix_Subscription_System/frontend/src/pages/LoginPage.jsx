import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const successNotice = location.state?.message;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          password: password,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        login({
          subscriptionId: data.subscriptionId,
          username: data.username,
          customerName: data.customerName,
          token: data.token,
        });
        navigate("/dashboard");
      } else {
        const data = await res.json().catch(() => ({}));
        setErrorMessage(data.message || "Invalid credentials");
      }
    } catch (err) {
      setErrorMessage("Connection error. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="container"
      style={{ maxWidth: "480px" }}
      data-testid="login-page"
    >
      <div className="form-card">
        <h1 className="form-title">Sign In</h1>
        <p className="form-subtitle">
          Access your StreamSub subscription and streaming dashboard.
        </p>

        {successNotice && (
          <div
            className="success-text"
            style={{ marginBottom: "16px", fontSize: "0.95rem" }}
            data-testid="success-banner"
          >
            ✓ {successNotice}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          {/* Username */}
          <div className="form-group">
            <label htmlFor="login-username">Username</label>
            <input
              id="login-username"
              type="text"
              className="form-control"
              placeholder="Your username"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
                setErrorMessage("");
              }}
              data-testid="input-login-username"
            />
          </div>

          {/* Password */}
          <div className="form-group">
            <label htmlFor="login-password">Password</label>
            <div className="password-wrapper">
              <input
                id="login-password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                className="form-control"
                placeholder="Your password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrorMessage("");
                }}
                data-testid="input-login-password"
              />
              <button
                type="button"
                className="eye-btn"
                onClick={() => setShowPassword(!showPassword)}
                data-testid="toggle-login-password-btn"
                aria-label="Toggle password visibility"
              >
                {showPassword ? "👁️" : "🙈"}
              </button>
            </div>
          </div>

          {/* Central Error Message below form */}
          {errorMessage && (
            <div className="central-error" data-testid="login-error-message">
              ⚠️ {errorMessage}
            </div>
          )}

          {/* Submit button: ALWAYS enabled until submit is clicked */}
          <button
            type="submit"
            className="btn-primary"
            style={{ width: "100%", marginTop: "8px" }}
            disabled={loading}
            data-testid="btn-login-submit"
          >
            {loading ? "Signing in..." : "Sign in"}
          </button>

          <div
            style={{ marginTop: "24px", textAlign: "center", color: "#AAAAAA" }}
          >
            New here?{" "}
            <Link to="/register" data-testid="link-register">
              Create an account
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
