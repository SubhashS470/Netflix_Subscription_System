import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function EditPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [initialData, setInitialData] = useState(null);
  const [formData, setFormData] = useState({
    customerName: "",
    mobileNumber: "",
    address: "",
    preferredGenre: "",
    planType: "",
    paymentType: "",
    paymentMethod: "",
    autoRenew: true,
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [serverError, setServerError] = useState("");

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    const fetchCurrent = async () => {
      try {
        const res = await fetch(`/api/subscription/${user.subscriptionId}`, {
          headers: {
            "X-Auth-User": user.username,
            Authorization: `Bearer ${user.token}`,
          },
        });
        if (res.ok) {
          const data = await res.json();
          setInitialData(data);
          setFormData({
            customerName: data.customerName || "",
            mobileNumber: data.mobileNumber || "",
            address: data.address || "",
            preferredGenre: data.preferredGenre || "",
            planType: data.planType || "Standard",
            paymentType: data.paymentType || "Monthly",
            paymentMethod: data.paymentMethod || "Credit Card",
            autoRenew: data.autoRenew !== undefined ? data.autoRenew : true,
          });
        } else {
          setServerError("Failed to load existing subscription.");
        }
      } catch (err) {
        setServerError("Network error loading subscription data.");
      } finally {
        setLoading(false);
      }
    };

    fetchCurrent();
  }, [user, navigate]);

  const validateField = (name, value) => {
    let err = "";
    if (name === "customerName") {
      if (!value.trim()) {
        err = "Customer name is required";
      } else if (!/^[a-zA-Z\s]{3,}$/.test(value.trim())) {
        err =
          "Name must be at least 3 characters and contain only letters and spaces";
      }
    } else if (name === "mobileNumber") {
      if (!value.trim()) {
        err = "Mobile number is required";
      } else if (!/^\d{10}$/.test(value.trim())) {
        err = "Mobile number must be exactly 10 digits";
      }
    }
    return err;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const val = type === "checkbox" ? checked : value;
    setFormData((prev) => ({ ...prev, [name]: val }));
    setServerError("");

    const fieldErr = validateField(name, val);
    setErrors((prev) => ({ ...prev, [name]: fieldErr }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const nameErr = validateField("customerName", formData.customerName);
    const mobileErr = validateField("mobileNumber", formData.mobileNumber);
    if (nameErr || mobileErr) {
      setErrors({ customerName: nameErr, mobileNumber: mobileErr });
      return;
    }

    // Determine changed fields only
    const changedFields = {};
    if (formData.customerName !== initialData.customerName)
      changedFields.customerName = formData.customerName.trim();
    if (formData.mobileNumber !== initialData.mobileNumber)
      changedFields.mobileNumber = formData.mobileNumber.trim();
    if (formData.address !== (initialData.address || ""))
      changedFields.address = formData.address.trim();
    if (formData.preferredGenre !== (initialData.preferredGenre || ""))
      changedFields.preferredGenre = formData.preferredGenre.trim();
    if (formData.planType !== initialData.planType)
      changedFields.planType = formData.planType;
    if (formData.paymentType !== initialData.paymentType)
      changedFields.paymentType = formData.paymentType;
    if (formData.paymentMethod !== initialData.paymentMethod)
      changedFields.paymentMethod = formData.paymentMethod;
    if (formData.autoRenew !== initialData.autoRenew)
      changedFields.autoRenew = formData.autoRenew;

    if (Object.keys(changedFields).length === 0) {
      navigate("/dashboard");
      return;
    }

    setSaving(true);
    setServerError("");

    try {
      const res = await fetch("/api/subscription/update", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-Auth-User": user.username,
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify(changedFields),
      });

      if (res.ok) {
        navigate("/dashboard");
      } else {
        const data = await res.json().catch(() => ({}));
        setServerError(data.message || "Failed to update subscription.");
      }
    } catch (err) {
      setServerError("Network error while updating subscription.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="container" data-testid="edit-loading">
        <p style={{ color: "#AAAAAA" }}>Loading subscription details...</p>
      </div>
    );
  }

  return (
    <div
      className="container"
      style={{ maxWidth: "680px" }}
      data-testid="edit-page"
    >
      <div className="form-card">
        <h1 className="form-title">Manage Plan & Connection</h1>
        <p className="form-subtitle">
          Update your profile, change your plan, or modify billing preferences.
        </p>

        {serverError && (
          <div className="central-error" data-testid="edit-server-error">
            ⚠️ {serverError}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          {/* Full Name */}
          <div className="form-group">
            <label htmlFor="edit-customerName">
              Full Name <span className="required">*</span>
            </label>
            <input
              id="edit-customerName"
              name="customerName"
              type="text"
              className="form-control"
              value={formData.customerName}
              onChange={handleChange}
              data-testid="input-edit-customer-name"
            />
            {errors.customerName && (
              <span
                className="error-text"
                data-testid="error-edit-customer-name"
              >
                {errors.customerName}
              </span>
            )}
          </div>

          {/* Mobile */}
          <div className="form-group">
            <label htmlFor="edit-mobileNumber">
              Mobile Number <span className="required">*</span>
            </label>
            <input
              id="edit-mobileNumber"
              name="mobileNumber"
              type="text"
              inputMode="numeric"
              maxLength={10}
              className="form-control"
              value={formData.mobileNumber}
              onChange={handleChange}
              data-testid="input-edit-mobile-number"
            />
            {errors.mobileNumber && (
              <span
                className="error-text"
                data-testid="error-edit-mobile-number"
              >
                {errors.mobileNumber}
              </span>
            )}
          </div>

          {/* Plan Type */}
          <div className="form-group">
            <label htmlFor="edit-planType">Plan</label>
            <select
              id="edit-planType"
              name="planType"
              className="form-control"
              value={formData.planType}
              onChange={handleChange}
              data-testid="select-edit-plan"
            >
              <option value="Mobile">Mobile (480p, 1 screen)</option>
              <option value="Basic">Basic (720p HD, 1 screen)</option>
              <option value="Standard">
                Standard (1080p Full HD, 2 screens)
              </option>
              <option value="Premium">
                Premium (4K+HDR, 4 screens, downloads)
              </option>
            </select>
          </div>

          {/* Payment Type */}
          <div className="form-group">
            <label htmlFor="edit-paymentType">
              Payment Type / Billing Cycle
            </label>
            <select
              id="edit-paymentType"
              name="paymentType"
              className="form-control"
              value={formData.paymentType}
              onChange={handleChange}
              data-testid="select-edit-payment-type"
            >
              <option value="Monthly">Monthly (+1 Month)</option>
              <option value="Quarterly">Quarterly (+3 Months)</option>
              <option value="Half-Yearly">Half-Yearly (+6 Months)</option>
              <option value="Annual">Annual (+12 Months)</option>
            </select>
            <small style={{ color: "#888", marginTop: "4px" }}>
              Note: Changing plan or billing cycle recalculates price and
              extends your subscription from the next billing cycle.
            </small>
          </div>

          {/* Payment Method */}
          <div className="form-group">
            <label htmlFor="edit-paymentMethod">Payment Method</label>
            <select
              id="edit-paymentMethod"
              name="paymentMethod"
              className="form-control"
              value={formData.paymentMethod}
              onChange={handleChange}
              data-testid="select-edit-payment-method"
            >
              <option value="Credit Card">Credit Card</option>
              <option value="Debit Card">Debit Card</option>
              <option value="UPI">UPI (Google Pay, PhonePe, Paytm)</option>
              <option value="Net Banking">Net Banking</option>
              <option value="PayPal">PayPal</option>
            </select>
          </div>

          {/* Address */}
          <div className="form-group">
            <label htmlFor="edit-address">Address</label>
            <input
              id="edit-address"
              name="address"
              type="text"
              className="form-control"
              value={formData.address}
              onChange={handleChange}
              data-testid="input-edit-address"
            />
          </div>

          {/* Preferred Genre */}
          <div className="form-group">
            <label htmlFor="edit-preferredGenre">Preferred Genre</label>
            <input
              id="edit-preferredGenre"
              name="preferredGenre"
              type="text"
              className="form-control"
              value={formData.preferredGenre}
              onChange={handleChange}
              data-testid="input-edit-preferred-genre"
            />
          </div>

          {/* Auto-renew */}
          <div
            className="form-group"
            style={{ flexDirection: "row", alignItems: "center", gap: "10px" }}
          >
            <input
              id="edit-autoRenew"
              name="autoRenew"
              type="checkbox"
              checked={formData.autoRenew}
              onChange={handleChange}
              data-testid="checkbox-edit-auto-renew"
            />
            <label
              htmlFor="edit-autoRenew"
              style={{ margin: 0, fontWeight: "normal", cursor: "pointer" }}
            >
              Auto-renew active subscription at end of billing cycle
            </label>
          </div>

          <div style={{ display: "flex", gap: "16px", marginTop: "24px" }}>
            <button
              type="submit"
              className="btn-primary"
              disabled={saving}
              data-testid="btn-save-changes"
            >
              {saving ? "Saving changes..." : "Save changes"}
            </button>
            <button
              type="button"
              className="btn-secondary"
              onClick={() => navigate("/dashboard")}
              data-testid="btn-cancel-edit"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
