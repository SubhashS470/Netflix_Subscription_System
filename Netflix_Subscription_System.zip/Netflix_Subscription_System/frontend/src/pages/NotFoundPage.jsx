import React from "react";
import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <div
      className="container"
      style={{ textAlign: "center", padding: "60px 20px" }}
      data-testid="not-found-page"
    >
      <h1
        style={{ fontSize: "4rem", color: "#E50914", marginBottom: "16px" }}
        data-testid="not-found-code"
      >
        404
      </h1>
      <h2
        style={{ fontSize: "1.75rem", marginBottom: "16px" }}
        data-testid="not-found-title"
      >
        Page Not Found
      </h2>
      <p
        style={{
          color: "#AAAAAA",
          marginBottom: "28px",
          maxWidth: "480px",
          margin: "0 auto 28px",
        }}
      >
        Sorry, the page you are looking for doesn't exist or has been moved.
        Check the URL or return to home.
      </p>
      <Link
        to="/dashboard"
        className="btn-primary"
        data-testid="not-found-home-link"
      >
        Go to Dashboard
      </Link>
    </div>
  );
}
