import React, { useState, useRef, useEffect } from "react";

const SUGGESTION_CHIPS = [
  "What should I watch tonight if I like dark thrillers?",
  "Is PREMIUM worth it over STANDARD?",
  "Recommend something like Stranger Things.",
  "What happens if I cancel my plan?",
];

export default function AiAssistantPage() {
  const [messages, setMessages] = useState([
    {
      sender: "bot",
      type: "policy",
      answer:
        "Hi! Ask me for viewing recommendations or questions about your plan. I'm an AI assistant, so double-check anything plan- or billing-specific against your Dashboard.",
      source_section: "support_information",
    },
  ]);
  const [inputQuery, setInputQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorBanner, setErrorBanner] = useState("");

  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (queryToSend) => {
    const query = (queryToSend || inputQuery).trim();
    if (!query || loading) return;

    // Add user message
    setMessages((prev) => [...prev, { sender: "user", text: query }]);
    setInputQuery("");
    setLoading(true);
    setErrorBanner("");

    try {
      const res = await fetch("/api/ai/recommend", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });

      if (res.ok) {
        const data = await res.json();
        setMessages((prev) => [...prev, { sender: "bot", ...data }]);
      } else {
        setErrorBanner(
          "Failed to receive response from AI Viewing Assistant. Please try again.",
        );
      }
    } catch (err) {
      setErrorBanner("Network error connecting to the AI Assistant.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container" data-testid="ai-assistant-page">
      <div style={{ marginBottom: "20px" }}>
        <h1
          style={{ fontSize: "2rem", fontWeight: 800 }}
          data-testid="assistant-title"
        >
          Viewing Assistant
        </h1>
        <p
          style={{ color: "#AAAAAA", fontSize: "0.95rem" }}
          data-testid="assistant-subtitle"
        >
          Powered by an LLM — answers are generated, not looked up from a fixed
          list.
        </p>
      </div>

      {errorBanner && (
        <div className="central-error" data-testid="assistant-error-banner">
          ⚠️ {errorBanner}
        </div>
      )}

      <div className="chat-container">
        {/* Chat message list */}
        <div className="chat-messages" data-testid="chat-messages-container">
          {messages.map((msg, idx) => {
            if (msg.sender === "user") {
              return (
                <div
                  key={idx}
                  className="chat-bubble user"
                  data-testid={`user-message-${idx}`}
                >
                  {msg.text}
                </div>
              );
            }

            // Bot message
            return (
              <div
                key={idx}
                className="chat-bubble bot"
                data-testid={`bot-message-${idx}`}
              >
                {msg.type === "content" ? (
                  <div data-testid="ai-content-card">
                    <div
                      style={{
                        fontWeight: 700,
                        color: "#E50914",
                        marginBottom: "8px",
                        fontSize: "1.1rem",
                      }}
                    >
                      🎬 Recommended Titles:
                    </div>
                    {msg.titles && msg.titles.length > 0 ? (
                      <ul
                        style={{ listStyle: "none", marginBottom: "10px" }}
                        data-testid="ai-titles-list"
                      >
                        {msg.titles.map((title, tIdx) => (
                          <li
                            key={tIdx}
                            style={{
                              fontSize: "1.05rem",
                              fontWeight: 600,
                              margin: "4px 0",
                            }}
                          >
                            ⭐ {title}{" "}
                            {msg.rating && msg.rating[tIdx]
                              ? `(${msg.rating[tIdx]}/10)`
                              : ""}
                          </li>
                        ))}
                      </ul>
                    ) : null}

                    {msg.genre && msg.genre.length > 0 && (
                      <div style={{ marginBottom: "8px" }}>
                        <span style={{ color: "#AAAAAA", fontSize: "0.85rem" }}>
                          Genres:{" "}
                        </span>
                        {msg.genre.map((g, gIdx) => (
                          <span
                            key={gIdx}
                            style={{
                              backgroundColor: "#404040",
                              padding: "2px 8px",
                              borderRadius: "4px",
                              fontSize: "0.8rem",
                              marginRight: "6px",
                            }}
                          >
                            {g}
                          </span>
                        ))}
                      </div>
                    )}

                    {msg.reason && (
                      <p
                        style={{
                          marginTop: "8px",
                          color: "#DDD",
                          fontSize: "0.95rem",
                        }}
                        data-testid="ai-reason"
                      >
                        💡 {msg.reason}
                      </p>
                    )}
                  </div>
                ) : (
                  <div data-testid="ai-policy-card">
                    <p
                      style={{ fontSize: "0.95rem", lineHeight: "1.5" }}
                      data-testid="ai-policy-answer"
                    >
                      {msg.answer || msg.text}
                    </p>
                    {msg.source_section && (
                      <div style={{ marginTop: "10px" }}>
                        <span
                          style={{
                            fontSize: "0.75rem",
                            textTransform: "uppercase",
                            backgroundColor: "#222",
                            color: "#888",
                            border: "1px solid #444",
                            padding: "2px 6px",
                            borderRadius: "4px",
                          }}
                          data-testid="ai-source-section"
                        >
                          Source: {msg.source_section}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {loading && (
            <div className="chat-bubble bot" data-testid="ai-loading-indicator">
              <span style={{ color: "#AAAAAA" }}>
                Assistant is thinking... ✍️
              </span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggestion Chips */}
        <div className="chat-chips" data-testid="suggestion-chips-container">
          {SUGGESTION_CHIPS.map((chip, idx) => (
            <button
              key={idx}
              type="button"
              className="chip-btn"
              onClick={() => handleSend(chip)}
              disabled={loading}
              data-testid={`suggestion-chip-${idx}`}
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Text Input & Send */}
        <div className="chat-input-bar">
          <input
            type="text"
            className="form-control"
            placeholder="Ask about what to watch, or your plan…"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSend();
            }}
            disabled={loading}
            data-testid="input-chat-query"
          />
          <button
            type="button"
            className="btn-primary"
            onClick={() => handleSend()}
            disabled={loading || !inputQuery.trim()}
            data-testid="btn-chat-send"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
