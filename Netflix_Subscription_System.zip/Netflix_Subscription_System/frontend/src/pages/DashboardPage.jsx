import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    const fetchSubscription = async () => {
      try {
        const res = await fetch(`/api/subscription/${user.subscriptionId}`, {
          headers: {
            "X-Auth-User": user.username,
            Authorization: `Bearer ${user.token}`,
          },
        });

        if (res.ok) {
          const data = await res.json();
          setSubscription(data);
        } else if (res.status === 401) {
          setError(
            "Unauthorized: Your session has expired. Please log in again.",
          );
        } else if (res.status === 404) {
          setError("Subscription record not found.");
        } else {
          setError("Unable to load subscription details.");
        }
      } catch (err) {
        setError("Network error loading dashboard.");
      } finally {
        setLoading(false);
      }
    };

    fetchSubscription();
  }, [user, navigate]);

  if (loading) {
    return (
      <div className="container" data-testid="dashboard-loading">
        <p style={{ color: "#AAAAAA" }}>Loading your subscription details...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container" data-testid="dashboard-error">
        <div className="central-error">{error}</div>
        <Link
          to="/login"
          className="btn-primary"
          style={{ display: "inline-block", marginTop: "12px" }}
        >
          Back to Login
        </Link>
      </div>
    );
  }

  return (
    <div className="container" data-testid="dashboard-page">
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "24px",
        }}
      >
        <div>
          <h1 style={{ fontSize: "2rem", fontWeight: 800 }}>
            Welcome back, {subscription.customerName}!
          </h1>
          <p style={{ color: "#AAAAAA" }}>
            Here is your active StreamSub membership and streaming status.
          </p>
        </div>
        <div style={{ display: "flex", gap: "12px" }}>
          <Link
            to="/subscription/edit"
            className="btn-primary"
            data-testid="btn-manage-plan"
          >
            Manage Plan
          </Link>
          <Link
            to="/ai-assistant"
            className="btn-secondary"
            data-testid="btn-ask-assistant"
          >
            Ask the Assistant
          </Link>
        </div>
      </div>

      <div className="form-card" data-testid="subscription-card">
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            borderBottom: "1px solid #333",
            paddingBottom: "18px",
            marginBottom: "20px",
          }}
        >
          <div>
            <span
              style={{
                fontSize: "0.85rem",
                color: "#AAAAAA",
                textTransform: "uppercase",
                letterSpacing: "1px",
              }}
            >
              Current Plan
            </span>
            <h2
              style={{ fontSize: "1.75rem", fontWeight: 700, color: "#E50914" }}
              data-testid="sub-plan-name"
            >
              {subscription.planType}
            </h2>
            <p
              style={{ color: "#CCCCCC", fontSize: "0.95rem" }}
              data-testid="sub-billing-cycle"
            >
              {subscription.paymentType} Billing Cycle
            </p>
          </div>
          <div style={{ textAlign: "right" }}>
            <span
              className={
                subscription.status === "ACTIVE"
                  ? "badge-active"
                  : "badge-inactive"
              }
              data-testid="sub-status-badge"
            >
              ● {subscription.status}
            </span>
            <div
              style={{ marginTop: "10px", fontSize: "1.5rem", fontWeight: 800 }}
              data-testid="sub-price"
            >
              ₹{subscription.price}
            </div>
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: "20px",
          }}
        >
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>
              Subscriber Name
            </span>
            <p style={{ fontWeight: 600 }} data-testid="sub-customer-name">
              {subscription.customerName}
            </p>
          </div>
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>Username</span>
            <p style={{ fontWeight: 600 }} data-testid="sub-username">
              {subscription.username}
            </p>
          </div>
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>Email</span>
            <p style={{ fontWeight: 600 }} data-testid="sub-email">
              {subscription.emailId}
            </p>
          </div>
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>Mobile</span>
            <p style={{ fontWeight: 600 }} data-testid="sub-mobile">
              {subscription.mobileNumber}
            </p>
          </div>
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>
              Start Date
            </span>
            <p style={{ fontWeight: 600 }} data-testid="sub-start-date">
              {subscription.startDate}
            </p>
          </div>
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>
              Current End Date
            </span>
            <p
              style={{ fontWeight: 600, color: "#2ECC71" }}
              data-testid="sub-end-date"
            >
              {subscription.endDate}
            </p>
          </div>
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>
              Payment Method
            </span>
            <p style={{ fontWeight: 600 }} data-testid="sub-payment-method">
              {subscription.paymentMethod}
            </p>
          </div>
          <div>
            <span style={{ color: "#888", fontSize: "0.85rem" }}>
              Auto-Renew
            </span>
            <p style={{ fontWeight: 600 }} data-testid="sub-auto-renew">
              {subscription.autoRenew ? "Enabled (Automatic)" : "Disabled"}
            </p>
          </div>
          {subscription.preferredGenre && (
            <div>
              <span style={{ color: "#888", fontSize: "0.85rem" }}>
                Preferred Genre
              </span>
              <p style={{ fontWeight: 600 }} data-testid="sub-preferred-genre">
                {subscription.preferredGenre}
              </p>
            </div>
          )}
          {subscription.address && (
            <div>
              <span style={{ color: "#888", fontSize: "0.85rem" }}>
                Address
              </span>
              <p style={{ fontWeight: 600 }} data-testid="sub-address">
                {subscription.address}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
