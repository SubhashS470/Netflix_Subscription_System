import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="navbar" data-testid="navbar">
      <Link
        to={user ? "/dashboard" : "/login"}
        className="brand"
        data-testid="brand-logo"
      >
        StreamSub
      </Link>
      <div className="nav-links">
        {user ? (
          <>
            <Link
              to="/dashboard"
              className="nav-link"
              data-testid="nav-dashboard"
            >
              Dashboard
            </Link>
            <Link
              to="/ai-assistant"
              className="nav-link"
              data-testid="nav-assistant"
            >
              Assistant
            </Link>
            <span
              style={{ color: "#AAAAAA", fontSize: "0.9rem" }}
              data-testid="nav-username"
            >
              👤 {user.username}
            </span>
            <button
              onClick={handleSignOut}
              className="btn-secondary"
              style={{ padding: "6px 14px", fontSize: "0.85rem" }}
              data-testid="nav-signout-btn"
            >
              Sign out
            </button>
          </>
        ) : (
          <>
            <Link
              to="/ai-assistant"
              className="nav-link"
              data-testid="nav-assistant-public"
            >
              Assistant
            </Link>
            <Link
              to="/register"
              className="nav-link"
              data-testid="nav-register"
            >
              Register
            </Link>
            <Link
              to="/login"
              className="btn-primary"
              style={{ padding: "8px 18px" }}
              data-testid="nav-login"
            >
              Login
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}
