# 🍿 StreamSub: The Ultimate Netflix-Style Subscription & AI Recommendation System
### *The Complete, Visual, Beginner-Friendly Blueprint from Scratch to Production*

---

## 📑 Table of Contents
1. [The Big Picture: What is StreamSub? (Explained Like You're 10)](#1-the-big-picture)
2. [Meme & Real-World Analogies: Meet the Cast](#2-meme--real-world-analogies)
3. [Architecture & System Flowcharts (Mermaid Diagrams)](#3-architecture--system-flowcharts)
4. [The Recipe Book: `pom.xml` Dependencies Explained](#4-the-recipe-book-pomxml-dependencies-explained)
5. [Configuration Central: `application.properties` Line-by-Line](#5-configuration-central-applicationproperties)
6. [Why `streamingservice_knowledge_base.json`? (The Open-Book Exam)](#6-why-streamingservice_knowledge_basejson)
7. [Backend Deep Dive: Package by Package, Class by Class](#7-backend-deep-dive)
   - [Model Layer (`Subscription.java`)](#71-model-layer)
   - [Repository Layer (`SubscriptionRepository.java`)](#72-repository-layer)
   - [DTO Layer (Data Transfer Objects)](#73-dto-layer)
   - [Exception Handling & The Global Safety Net](#74-exception-handling)
   - [Service Layer (`KnowledgeBaseLoader` & `SubscriptionService`)](#75-service-layer)
   - [AI Engine (`PromptBuilder` & `LlmClientImpl`)](#76-ai-engine)
   - [Controller Layer (`AuthController`, `SubscriptionController`, `AiController`)](#77-controller-layer)
8. [Frontend Deep Dive: React, JSX, CSS & Component Magic](#8-frontend-deep-dive)
   - [Authentication State (`AuthContext.jsx`)](#81-auth-context)
   - [The Navigation Hub (`Navbar.jsx`)](#82-navbar)
   - [Registration Page (`ApplyPage.jsx`)](#83-apply-page)
   - [Login Portal (`LoginPage.jsx`)](#84-login-page)
   - [Dashboard (`DashboardPage.jsx`)](#85-dashboard-page)
   - [Manage Plan Page (`EditPage.jsx`)](#86-edit-page)
   - [AI Viewing Assistant (`AiAssistantPage.jsx`)](#87-ai-viewing-assistant)
   - [Dark Cinematic Styling (`index.css`)](#88-styling-architecture)
9. [How the Automated Tests Verify Everything](#9-testing--verification)

---

<a name="1-the-big-picture"></a>
## 1. 🎬 The Big Picture: What is StreamSub?

Imagine you run an ultra-modern digital cinema:
- **Customers** want to buy a ticket (Subscription), pick whether they watch on a phone or an IMAX 4K home theater (Plans), and decide whether to pay each month or once a year (Payment Types).
- **The Cashier & Database** must ensure nobody sneaks in with a duplicate active pass, never saves their secret password in plain English, and knows exactly when their subscription expires down to the exact day.
- **The AI Viewing Genie** sits in the lobby. If a customer walks up and asks *"What should I watch tonight if I love Stranger Things?"* or *"What happens if I cancel my subscription?"*, the Genie answers truthfully using the theater's official handbook without inventing fake movies or fake prices!

This full-stack system has two main halves:
1. **The Backend (Spring Boot 3 + Java 21)**: The strong, reliable engine room holding the database, verifying rules, hashing passwords, and connecting to the AI.
2. **The Frontend (React 18 + Vite)**: The gorgeous, fast, dark-themed Netflix-like UI with smooth red accents, live price updates, inline error validations, and an AI chatroom.

---

<a name="2-meme--real-world-analogies"></a>
## 2. 🎭 Meme & Real-World Analogies: Meet the Cast

| Component | Real-World Role | Meme Analogy |
|---|---|---|
| **`React Frontend (Vite)`** | The sleek cinema lobby with glowing red neon signs. | *"Look at my gorgeous UI... please don't click 100 times before it loads."* |
| **`AuthController`** | The front-desk receptionist checking IDs. | *"ID card please. Oh, your password doesn't match? 'Invalid credentials' – no hints for you!"* |
| **`BCryptPasswordEncoder`** | A giant paper shredder + meat grinder. | *"You gave me 'MySecretPass123'? Cool, I turned it into `$2a$10$e8FjK9...`! Even I can't turn it back!"* |
| **`SubscriptionService`** | The strict theater manager calculating calendars and prices. | *"You picked Annual? Great, add exactly 12 months. Mobile plan? That will be ₹1499."* |
| **`H2 In-Memory Database`** | An ultra-fast magical digital whiteboard. | *"Super fast in RAM! Just don't pull the server plug without saving!"* |
| **`Knowledge Base JSON`** | The official company encyclopedia & rulebook. | *"Everything the AI is allowed to know. No wild guessing allowed."* |
| **`PromptBuilder & LlmClient`** | The translator who hands the rulebook to Claude Haiku AI. | *"Here is the exact rulebook. Answer ONLY from this. Do NOT hallucinate!"* |

---

<a name="3-architecture--system-flowcharts"></a>
## 3. 🗺️ Architecture & System Flowcharts

### 3.1 High-Level Architecture Diagram
```mermaid
graph TD
    User([👤 User / Browser])
    
    subgraph Frontend [React 18 + Vite Frontend - Port 3000]
        Router[React Router DOM]
        Apply[ApplyPage - /register & /apply]
        Login[LoginPage - /login]
        Dash[DashboardPage - /dashboard]
        Edit[EditPage - /subscription/edit]
        AIUI[AiAssistantPage - /ai-assistant]
        AuthCtx[AuthContext - LocalStorage Token]
    end

    subgraph Backend [Spring Boot 3 Backend - Port 8080]
        AuthCtrl[AuthController]
        SubCtrl[SubscriptionController]
        AiCtrl[AiController]
        
        SubService[SubscriptionService]
        KBLoader[KnowledgeBaseLoader]
        BCrypt[BCrypt PasswordEncoder]
        PromptBld[PromptBuilder]
        LlmClt[LlmClientImpl]
        
        SubRepo[SubscriptionRepository]
        H2DB[(H2 Database in RAM)]
    end

    subgraph External [External AI Gateway]
        Claude[Tekstac LLM Gateway / Claude 3 Haiku]
    end

    User --> Router
    Router --> Apply
    Router --> Login
    Router --> Dash
    Router --> Edit
    Router --> AIUI
    
    Apply -->|POST /api/auth/register| AuthCtrl
    Apply -->|GET /api/auth/check-*| AuthCtrl
    Login -->|POST /api/auth/login| AuthCtrl
    Dash -->|GET /api/subscription/:id| SubCtrl
    Edit -->|PUT /api/subscription/update| SubCtrl
    AIUI -->|POST /api/ai/recommend| AiCtrl
    
    AuthCtrl --> SubService
    SubCtrl --> SubService
    AiCtrl --> LlmClt
    
    SubService --> BCrypt
    SubService --> KBLoader
    SubService --> SubRepo
    SubRepo --> H2DB
    
    LlmClt --> PromptBld
    PromptBld --> KBLoader
    LlmClt -->|HTTPS REST| Claude
```

---

### 3.2 User Registration Flow (`POST /api/auth/register`)
```mermaid
sequenceDiagram
    autonumber
    actor Customer as 👤 Customer
    participant React as 🖥️ ApplyPage (React)
    participant Auth as 🚪 AuthController
    participant Service as ⚙️ SubscriptionService
    participant BCrypt as 🔒 BCrypt Encoder
    participant KB as 📚 KnowledgeBaseLoader
    participant DB as 🗄️ SubscriptionRepository (H2)

    Customer->>React: Fills Form (Name, Mobile, Email, Pass, Plan, Cycle)
    Note over React: Instant live validation + async availability check
    React->>Auth: POST /api/auth/register (JSON)
    Auth->>Service: register(RegisterRequest)
    
    Service->>DB: findByEmailIdIgnoreCase(email)
    alt Already has ACTIVE subscription?
        DB-->>Service: Found active subscription!
        Service-->>Auth: Throw ConflictException (409)
        Auth-->>React: 409 Conflict ("Active subscription already exists")
    else Only INACTIVE or New Email
        Service->>DB: existsByUsername(username)
        alt Username already taken?
            DB-->>Service: True!
            Service-->>Auth: Throw ConflictException (409)
            Auth-->>React: 409 Conflict ("Username taken")
        else Username available
            Service->>BCrypt: encode(rawPassword)
            BCrypt-->>Service: $2a$10$... (Safe Hash)
            Service->>KB: getPrice(planType, paymentType)
            KB-->>Service: ₹499.00
            Service->>Service: Compute EndDate = Today + 1/3/6/12 Months
            Service->>DB: save(new Subscription)
            DB-->>Service: Saved Subscription entity
            Service-->>Auth: SubscriptionResponse (NO password!)
            Auth-->>React: 201 Created + JSON
            React->>Customer: Redirect to /login with Success Banner!
        end
    end
```

---

### 3.3 AI Viewing Assistant Flow (`POST /api/ai/recommend`)
```mermaid
sequenceDiagram
    autonumber
    actor User as 👤 Viewer
    participant UI as 💬 AiAssistantPage
    participant Ctrl as 🤖 AiController
    participant Client as ⚡ LlmClientImpl
    participant Builder as 📝 PromptBuilder
    participant KB as 📚 KnowledgeBaseLoader
    participant LLM as ☁️ Claude 3 Haiku Gateway

    User->>UI: Clicks chip or types: "Recommend something like Stranger Things"
    UI->>Ctrl: POST /api/ai/recommend { query: "..." }
    Ctrl->>Client: generateResponse(query)
    Client->>Builder: buildSystemPrompt()
    Builder->>KB: Get content_catalog, plans, policies, faqs
    KB-->>Builder: Full structured JSON knowledge
    Builder-->>Client: Complete grounded System Prompt
    Client->>LLM: POST /chat/completions with Bearer Token & Temperature 0.2
    
    alt LLM returns valid JSON
        LLM-->>Client: { "type": "content", "titles": ["Stranger Things", "Dark Shadows"], ... }
        Client->>Client: Strip code fences, parse into AiResponse
        Client-->>Ctrl: AiResponse object
        Ctrl-->>UI: 200 OK + AiResponse
        UI->>User: Displays movie cards with star ratings & genres!
    else LLM offline or times out
        Client->>Client: Catch timeout / error
        Client-->>Ctrl: Fallback to support_information
        Ctrl-->>UI: 200 OK + Grounded fallback answer
        UI->>User: Shows polite explanation & support contact
    end
```

---

<a name="4-the-recipe-book-pomxml-dependencies-explained"></a>
## 4. 📦 The Recipe Book: `pom.xml` Dependencies Explained

In Java, Maven's `pom.xml` is like the ingredients list of a cake. Without it, Java doesn't know how to cook:

```xml
<dependencies>
    <!-- 1. THE WAITER & CHEF: Spring Boot Starter Web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
```
> **Why do we need it?** It gives us Apache Tomcat (an embedded web server), Spring MVC (`@RestController`, `@GetMapping`, `@PostMapping`), and Jackson JSON serializer. Without this, our backend cannot receive HTTP requests from React!

```xml
    <!-- 2. THE LIBRARIAN: Spring Boot Starter Data JPA -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
```
> **Why do we need it?** It connects Java objects to database tables using Hibernate/JPA. It creates our `SubscriptionRepository` automatically so we don't have to write tedious SQL `SELECT * FROM subscriptions WHERE...` by hand!

```xml
    <!-- 3. THE INSPECTOR: Spring Boot Starter Validation -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>
```
> **Why do we need it?** It enables annotations like `@NotBlank`, `@Email`, and `@Pattern`. When someone submits a registration, Spring inspects every field before our code even runs. If the phone number is 9 digits instead of 10, the inspector rejects it immediately with a friendly message.

```xml
    <!-- 4. THE SECRET MEAT GRINDER: Spring Security Crypto -->
    <dependency>
        <groupId>org.springframework.security</groupId>
        <artifactId>spring-security-crypto</artifactId>
    </dependency>
```
> **Why do we need it?** It gives us `BCryptPasswordEncoder`. Storing raw passwords like `"Password123"` in a database is illegal in production software. BCrypt hashes it into a one-way mathematical code so even database admins cannot see customer passwords.

```xml
    <!-- 5. THE MAGIC WHITEBOARD: H2 In-Memory Database -->
    <dependency>
        <groupId>com.h2database</groupId>
        <artifactId>h2</artifactId>
        <scope>runtime</scope>
    </dependency>
```
> **Why do we need it?** H2 is a lightweight SQL database that runs entirely in computer memory (RAM). You don't need to install or configure Oracle, MySQL, or Postgres! Perfect for lightning-fast tests, local evaluation, and zero-configuration development.

```xml
    <!-- 6. THE INSPECTOR'S MAGNIFYING GLASS: Spring Boot Starter Test -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```
> **Why do we need it?** It provides JUnit 5, Mockito (for mocking databases and AI calls), and MockMvc (for testing REST controllers without opening a real browser).

---

<a name="5-configuration-central-applicationproperties"></a>
## 5. ⚙️ Configuration Central: `application.properties`

Located at `backend/src/main/resources/application.properties`:

```properties
# 1. The port where the Java backend listens
server.port=8080

# 2. Database Connection URL: Tells Hibernate to store tables in RAM with name 'streamsubdb'
spring.datasource.url=jdbc:h2:mem:streamsubdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=

# 3. Tell Hibernate to automatically create & update the SQL tables whenever Java starts up
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.jpa.hibernate.ddl-auto=update

# 4. Enable the visual browser web console at http://localhost:8080/h2-console
spring.h2.console.enabled=true

# 5. STRICT AI CONFIGURATION: Read strictly from environment variables CLAUDE_HAIKU_API_KEY and LLM_BASE_URL
llm.api-key=${CLAUDE_HAIKU_API_KEY:}
llm.base-url=${LLM_BASE_URL:https://llmgateway-cognizant-assessment.tekstac.com/v1}
llm.model=claude-3-haiku-20240307
```

**Why `${CLAUDE_HAIKU_API_KEY:}` syntax?**
The colon `:` means: *If this environment variable exists in the operating system, use it. If not, default to empty string instead of crashing the server on startup.* This allows unit tests to run cleanly in offline environments!

---

<a name="6-why-streamingservice_knowledge_basejson"></a>
## 6. 🧠 Why `streamingservice_knowledge_base.json`? (The Open-Book Exam)

### The Problem with Normal AI:
If you ask an AI model like ChatGPT: *"How much does the Mobile plan cost on StreamSub?"*, it has never heard of StreamSub before! It will hallucinate and guess: *"It costs $9.99 a month"*. **That causes immediate test failures and angry customers!**

### The Solution: Grounded Knowledge (RAG - Retrieval-Augmented Generation)
We give the AI an **open-book exam**. We load `streamingservice_knowledge_base.json` into RAM once at startup:

```
streamingservice_knowledge_base.json
├── 1. content_catalog[]      -> Titles, genres, cast, descriptions, IMDb ratings, runtimes, mood tags
├── 2. subscription_plans[]   -> Mobile, Basic, Standard, Premium (screens, quality, prices for 4 cycles)
├── 3. policies{}             -> Cancellation rules, pause rules, refunds, account limits, support info
└── 4. faqs[]                 -> 11 official Questions & Answers
```

When someone chats with the assistant, our `PromptBuilder` takes their query, glues the **entire book** to the prompt, and tells Claude Haiku:
> *"You are taking an open-book test. If the answer is in this text, answer it. If the answer is NOT in this text, do NOT invent anything; point them to `support@streamsub.com`!"*

---

<a name="7-backend-deep-dive"></a>
## 7. ☕ Backend Deep Dive: Package by Package, Class by Class

```
com.streamsub.netflix
├── ai/          -> AI prompt building and LLM client communication
├── controller/  -> HTTP REST API endpoints (receives requests, returns JSON)
├── dto/         -> Safe data carriers between client and server
├── exception/   -> Custom error types and global error handler
├── model/       -> JPA Database Entity (the SQL table schema)
├── repository/  -> Spring Data JPA queries
└── service/     -> Business logic (passwords, dates, prices, duplicate checks)
```

---

<a name="71-model-layer"></a>
### 7.1 Model Layer: `Subscription.java`
**Location**: `src/main/java/com/streamsub/netflix/model/Subscription.java`

This class is the **blueprint** of our SQL table:
- `@Entity` and `@Table(name = "subscriptions")`: Tells Spring: *Make an SQL table called `subscriptions`.*
- `@Id @GeneratedValue(strategy = GenerationType.IDENTITY)`: An auto-incrementing integer Primary Key (`1, 2, 3...`).
- `customerName`: String (e.g., `"John Doe"`).
- `mobileNumber`: 10-digit string.
- `emailId`: Customer email.
- `planType`: `"MOBILE"`, `"BASIC"`, `"STANDARD"`, or `"PREMIUM"`.
- `paymentType`: `"MONTHLY"`, `"QUARTERLY"`, `"HALF_YEARLY"`, or `"ANNUAL"`.
- `startDate`: `LocalDate` (set to `LocalDate.now()`).
- `endDate`: `LocalDate` (calculated dynamically based on payment type).
- `status`: Stored strictly as `"ACTIVE"` or `"INACTIVE"`.
- `paymentMethod`: Secure token string (e.g., `"Credit Card"`, `"UPI"`, never raw card numbers).
- `username`: Unique login name.
- `password`: Stored as a **BCrypt hash** (e.g., `$2a$10$7R...`).
- `price`: Double (e.g., `499.0`).
- `autoRenew`: Boolean.
- `address` & `preferredGenre`: Optional customizable fields.

---

<a name="72-repository-layer"></a>
### 7.2 Repository Layer: `SubscriptionRepository.java`
**Location**: `src/main/java/com/streamsub/netflix/repository/SubscriptionRepository.java`

```java
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    Optional<Subscription> findByUsername(String username);
    boolean existsByUsername(String username);
    List<Subscription> findByEmailIdIgnoreCase(String emailId);
    boolean existsByEmailIdIgnoreCaseAndStatus(String emailId, String status);
    Optional<Subscription> findByEmailIdIgnoreCaseAndStatus(String emailId, String status);
}
```
**Why this matters**:
- Spring Data JPA reads method names and automatically constructs SQL queries!
- `findByEmailIdIgnoreCase`: Replaces writing `SELECT * FROM subscriptions WHERE LOWER(email_id) = LOWER(?)`.
- This powers our **defect fix**: when someone registers, we check if they already have an `ACTIVE` subscription. If their previous subscription is `INACTIVE`, they are legally allowed to re-subscribe!

---

<a name="73-dto-layer"></a>
### 7.3 DTO Layer (Data Transfer Objects)
**Location**: `src/main/java/com/streamsub/netflix/dto/`

DTOs are like envelopes. You never mail your whole house; you mail a letter inside an envelope:

1. **`RegisterRequest.java`**:
   - Contains server-side `@Pattern` annotations:
     - `@Pattern(regexp = "^[a-zA-Z\\s]{3,}$")`: Name must have $\ge 3$ letters, no numbers.
     - `@Pattern(regexp = "^\\d{10}$")`: Mobile must be exactly 10 digits.
     - `@Email`: Validates email format.
     - `@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&#]).{8,}$")`: Password requires at least 8 characters, 1 uppercase, 1 lowercase, 1 digit, and 1 special symbol.
2. **`SubscriptionResponse.java`**:
   - Contains all subscription details to send to React, but **noticeably omits `password`**! This guarantees passwords are never leaked in network responses.
3. **`LoginRequest.java` & `LoginResponse.java`**:
   - Holds `{ username, password }` coming in, and returns `{ subscriptionId, username, token, message }` going out.
4. **`UpdateRequest.java`**:
   - Allows partial updates for `customerName`, `mobileNumber`, `address`, `preferredGenre`, `planType`, `paymentType`.
5. **`AvailabilityResponse.java`**:
   - Simple `{ available: true/false }` for async frontend checks.
6. **`AiRequest.java` & `AiResponse.java`**:
   - Holds `{ query }` input and flexible `{ type, titles, genre, reason, rating, answer, source_section }` output.

---

<a name="74-exception-handling"></a>
### 7.4 Exception Handling: `GlobalExceptionHandler.java`
**Location**: `src/main/java/com/streamsub/netflix/exception/GlobalExceptionHandler.java`

Whenever an error happens in our code, we don't want the server to throw a messy Java stack trace with HTML error 500. This class catches exceptions and returns neat JSON:
- `ConflictException` $\rightarrow$ **HTTP 409 Conflict** (e.g. active subscription email or username already exists).
- `UnauthorizedException` $\rightarrow$ **HTTP 401 Unauthorized** (e.g. wrong password or viewing someone else's connection).
- `ResourceNotFoundException` $\rightarrow$ **HTTP 404 Not Found** (e.g. ID doesn't exist).
- `MethodArgumentNotValidException` $\rightarrow$ **HTTP 400 Bad Request** (validation errors on inputs).

---

<a name="75-service-layer"></a>
### 7.5 Service Layer: `SubscriptionService.java`
**Location**: `src/main/java/com/streamsub/netflix/service/SubscriptionService.java`

This is the brain of the backend. Let's trace its key methods:

#### 1. Registration (`register`)
```java
// Check if password and confirm password match
if (!request.getPassword().equals(request.getConfirmPassword())) {
    throw new IllegalArgumentException("Password and confirm password do not match");
}

// Check for ACTIVE subscription with email (case-insensitive)
List<Subscription> existingByEmail = repository.findByEmailIdIgnoreCase(request.getEmailId().trim());
boolean hasActive = existingByEmail.stream()
        .anyMatch(sub -> "ACTIVE".equalsIgnoreCase(sub.getStatus()));
if (hasActive) {
    throw new ConflictException("An active subscription already exists for this email address");
}

// Check username uniqueness
if (repository.existsByUsername(request.getUsername().trim())) {
    throw new ConflictException("Username already exists. Please choose a different username");
}

// Hash password with BCrypt
sub.setPassword(passwordEncoder.encode(request.getPassword()));

// Calculate End Date
sub.setStartDate(LocalDate.now());
sub.setEndDate(calculateEndDate(LocalDate.now(), normalizedPayment));
sub.setStatus("ACTIVE");
```

#### 2. End Date Calculation Formula
```java
private LocalDate calculateEndDate(LocalDate startDate, String paymentType) {
    String pt = paymentType.toUpperCase(Locale.ROOT);
    if (pt.contains("HALF")) {
        return startDate.plusMonths(6);   // Half-Yearly: +6 Months
    } else if (pt.contains("ANNUAL") || pt.contains("YEAR")) {
        return startDate.plusMonths(12);  // Annual: +12 Months
    } else if (pt.contains("QUART")) {
        return startDate.plusMonths(3);   // Quarterly: +3 Months
    } else {
        return startDate.plusMonths(1);   // Monthly: +1 Month
    }
}
```
> ⚠️ **Key Bug Fixed**: Notice `pt.contains("HALF")` is checked **before** `pt.contains("YEAR")`. In naive code, `"HALF_YEARLY"` matches `"YEAR"`, accidentally giving a 6-month customer a whole year for free!

#### 3. Login Verification (`login`)
```java
Subscription sub = repository.findByUsername(request.getUsername().trim())
        .orElseThrow(() -> new UnauthorizedException("Invalid credentials"));

if (!passwordEncoder.matches(request.getPassword(), sub.getPassword())) {
    throw new UnauthorizedException("Invalid credentials");
}
```
> 🛡️ **Security Defense**: Both wrong password and missing username return the exact same generic string `"Invalid credentials"` and HTTP 401. Hackers cannot guess which usernames exist in our database.

#### 4. Updating a Connection (`updateSubscription`)
When a user updates their plan (e.g., Basic $\rightarrow$ Premium) or billing cycle (Monthly $\rightarrow$ Annual):
- Only changed fields are updated.
- If plan or payment type changes, the new duration is added onto the **current end date** (the next billing cycle):
  ```java
  LocalDate currentEnd = sub.getEndDate() != null ? sub.getEndDate() : LocalDate.now();
  sub.setEndDate(calculateEndDate(currentEnd, newPayment));
  sub.setPrice(knowledgeBaseLoader.getPrice(newPlan, newPayment));
  ```

---

<a name="76-ai-engine"></a>
### 7.6 AI Engine: `PromptBuilder.java` & `LlmClientImpl.java`

#### `PromptBuilder.java`
Builds the comprehensive System Prompt. It injects:
1. Grounding directive: *"Never invent movies, prices, or policies."*
2. Classification rules:
   - Content queries: Return JSON with `type: "content"`, `titles`, `genre`, `reason`, `rating`.
   - Policy queries: Return JSON with `type: "policy"`, `answer`, `source_section`.
3. The complete `streamingservice_knowledge_base.json` serialized as text.

#### `LlmClientImpl.java`
1. Makes an HTTP POST request to:
   $$\text{POST } \{\text{llm.base-url}\} + \text{"/chat/completions"}$$
2. Passes headers: `Authorization: Bearer <CLAUDE_HAIKU_API_KEY>`.
3. Passes body with `temperature: 0.2` (low temperature prevents creative hallucinations).
4. Cleans the response:
   ```java
   // Strip markdown code fences if LLM wrapped output in ```json
   if (cleaned.startsWith("```json")) cleaned = cleaned.substring(7);
   if (cleaned.endsWith("```")) cleaned = cleaned.substring(0, cleaned.length() - 3);
   ```
5. If the AI service fails or the query is completely unknown, it gracefully triggers the fallback:
   ```java
   return AiResponse.fallback(knowledgeBaseLoader.getSupportInformation());
   ```

---

<a name="77-controller-layer"></a>
### 7.7 Controller Layer (REST Endpoints)
- **`AuthController.java`**:
  - `POST /api/auth/register` $\rightarrow$ Returns 201 Created.
  - `POST /api/auth/login` $\rightarrow$ Returns 200 OK with token.
  - `GET /api/auth/check-email?email=...` $\rightarrow$ Returns `{ available: boolean }`.
  - `GET /api/auth/check-username?username=...` $\rightarrow$ Returns `{ available: boolean }`.
- **`SubscriptionController.java`**:
  - `GET /api/subscription/{id}` $\rightarrow$ Returns connection JSON (requires user authentication).
  - `PUT /api/subscription/update` $\rightarrow$ Updates changed fields.
  - `GET /api/subscription/plans` $\rightarrow$ Serves available plans and pricing.
- **`AiController.java`**:
  - `POST /api/ai/recommend` $\rightarrow$ Publicly accessible AI endpoint for recommendations and questions.

---

<a name="8-frontend-deep-dive"></a>
## 8. ⚛️ Frontend Deep Dive: React, JSX, CSS & Component Magic

```
frontend/src/
├── components/
│   └── Navbar.jsx        -> Top navigation bar with active authentication state
├── context/
│   └── AuthContext.jsx   -> Global state management for logged-in user
├── pages/
│   ├── ApplyPage.jsx     -> Registration form with live plan cards & async checks
│   ├── LoginPage.jsx     -> Sign-in screen with password eye toggle
│   ├── DashboardPage.jsx -> Subscriber summary card & quick actions
│   ├── EditPage.jsx      -> Manage plan & update profile
│   ├── AiAssistantPage.jsx -> Interactive AI viewing assistant chat
│   └── NotFoundPage.jsx  -> 404 error page
├── App.jsx               -> React Router routes & protected route wrapper
├── index.css             -> StreamSub dark cinematic theme styling
└── main.jsx              -> Vite root bootstrap
```

---

<a name="81-auth-context"></a>
### 8.1 Authentication State: `AuthContext.jsx`
Think of `AuthContext` as the **VIP wristband** at a concert:
- When a user signs in, we store their details in `localStorage` under key `streamsub_user`.
- Any component in the app can call `useAuth()` to check:
  - Is someone logged in? (`user != null`)
  - What is their name and token?
  - `logout()`: Snips the wristband and clears `localStorage`.

---

<a name="82-navbar"></a>
### 8.2 The Navigation Hub: `Navbar.jsx`
- Displays the red glowing **StreamSub** logo (`/`).
- **If Logged In**: Displays links to `Dashboard`, `Assistant`, user greeting (`👤 john_doe`), and a `Sign out` button.
- **If Logged Out**: Displays links to `Assistant`, `Register`, and a prominent red `Login` button.

---

<a name="83-apply-page"></a>
### 8.3 Registration Page: `ApplyPage.jsx` (`/register` & `/apply`)
This is the most feature-rich screen in the application.

#### Key Mechanics:
1. **Interactive Plan Cards**:
   Four cards rendered from `PLAN_DATA`:
   - Mobile: 480p, 1 screen.
   - Basic: 720p HD, 1 screen.
   - Standard: 1080p Full HD, 2 screens.
   - Premium: 4K + HDR, 4 screens, downloads on 6 devices.
   
   When the user switches the **Payment Type dropdown** from `Monthly` to `Annual`:
   $$\text{Price updates instantly without a page reload!}$$
   ```jsx
   const price = plan.pricing[formData.paymentType];
   // Mobile changes from ₹149/mo to ₹1499/annual immediately!
   ```

2. **Inline Red Error Validation that Clears Instantly**:
   - Every input has an error text element right below it.
   - As soon as the user corrects their error (e.g., types the 10th digit of their phone number), `validateField` re-evaluates and the red error vanishes instantly!

3. **Asynchronous Availability Checking on Blur**:
   - When the user finishes typing their email or username and clicks away (`onBlur`), a background `fetch` checks `/api/auth/check-email`.
   - If available, a bright green message appears: `"✓ email is available"`.
   - If taken, a red error appears: `"✗ An active subscription already exists for this email"`.

4. **Show/Hide Password Eye Icons**:
   Clicking the eye button toggles the input type between `"password"` and `"text"`.

5. **Submit Button Safety**:
   The `Create account` button is disabled until both a **Plan** and a **Payment Type** have been chosen.

---

<a name="84-login-page"></a>
### 8.4 Login Portal: `LoginPage.jsx` (`/login`)
- **Always-Enabled Button**: As required by US-004, the login button is always clickable until the network request begins.
- **Central Error Banner**: Individual fields don't show separate red borders. Instead, if authentication fails, a unified central error banner appears:
  ```
  ⚠️ Invalid credentials
  ```
- **Password AutoComplete**: Has `autoComplete="current-password"` for browser password managers.

---

<a name="85-dashboard-page"></a>
### 8.5 Subscriber Dashboard: `DashboardPage.jsx` (`/dashboard`)
Protected route that fetches `GET /api/subscription/{id}`:
- **Status Badge**: Glowing green `● ACTIVE` badge or grey `● INACTIVE`.
- **Card Overview**: Displays Current Plan (`PREMIUM`), Billing Cycle (`QUARTERLY`), Price (`₹1819`), Start Date, End Date, and Payment Method.
- **Quick Actions**:
  - `Manage Plan`: Links to `/subscription/edit`.
  - `Ask the Assistant`: Links to `/ai-assistant`.

---

<a name="86-edit-page"></a>
### 8.6 Manage Plan Page: `EditPage.jsx` (`/subscription/edit`)
- Pre-fills all current subscriber details.
- Validates name and mobile.
- Allows upgrading/downgrading plan tier and payment cycle.
- Calculates changed fields only and submits `PUT /api/subscription/update`.
- Redirects back to `/dashboard` upon success.

---

<a name="87-ai-viewing-assistant"></a>
### 8.7 AI Viewing Assistant: `AiAssistantPage.jsx` (`/ai-assistant` & `/assistant`)
- **Subtitle**: *"Powered by an LLM — answers are generated, not looked up from a fixed list."*
- **Greeting**: Starts with a friendly bot message reminding users to check their dashboard for official billing items.
- **Suggestion Chips**: 4 pre-built buttons:
  1. *"What should I watch tonight if I like dark thrillers?"*
  2. *"Is PREMIUM worth it over STANDARD?"*
  3. *"Recommend something like Stranger Things."*
  4. *"What happens if I cancel my plan?"*
- **Dual Response Rendering**:
  - If `type === "content"`: Renders movie recommendation cards with ⭐ ratings, genre badges, and matching logic.
  - If `type === "policy"`: Renders the grounded explanation and a badge indicating the source section (e.g. `SOURCE: POLICIES`).
- Also accessible from the **Apply page** so visitors can ask plan questions before buying.

---

<a name="88-styling-architecture"></a>
### 8.8 Dark Cinematic Styling: `index.css`
- **Background**: Deep carbon black (`#141414`).
- **Cards**: Charcoal surfaces (`#1F1F1F`) with subtle borders (`#2E2E2E`).
- **Brand Primary Accent**: Official cinematic red (`#E50914`).
- **Input Focus**: Subtle red glow outline.
- **Badges**: Active green (`#2ECC71`), Inactive grey (`#BDC3C7`).

---

<a name="9-testing--verification"></a>
## 9. 🧪 How the Automated Tests Verify Everything

Running `mvn test` executes **18 automated tests across 4 test classes**:

| Test Class | What It Tests | Expected Result |
|---|---|---|
| **`SubscriptionServiceTest`** | **Login tests executed FIRST**: valid credentials return 200, wrong password returns 401 with generic message, unknown user returns 401 with identical message. | ✅ Passed |
| **`SubscriptionServiceTest`** | **Registration across all 4 plans $\times$ 4 payment types** (16 combinations). Verifies correct durations (+1, +3, +6, +12 months), prices, and BCrypt encoding. | ✅ Passed |
| **`SubscriptionServiceTest`** | Duplicate active email returns 409; re-registering when prior subscriptions are `INACTIVE` is allowed; duplicate username returns 409. | ✅ Passed |
| **`SubscriptionServiceTest`** | Update subscription recalculates price and extends end date from current end date. | ✅ Passed |
| **`PromptBuilderTest`** | Ensures prompt contains all 4 knowledge base sections (`content_catalog`, `subscription_plans`, `policies`, `faqs`) and strict JSON instructions. | ✅ Passed |
| **`AiControllerTest`** | Content recommendation returns title/genre/reason/rating; policy queries return answer/source_section; blank queries return 400. | ✅ Passed |
| **`AuthControllerTest`** | Endpoints `/register`, `/check-email`, and `/check-username` return expected JSON codes. | ✅ Passed |

---

### 🚀 How to Run the Project Locally

#### 1. Start the Backend:
```powershell
cd C:\Subhash\Self-Driven\React_Project\Netflix_Subscription_System\backend
mvn spring-boot:run
```
*Backend runs on `http://localhost:8080` (H2 database console at `http://localhost:8080/h2-console`).*

#### 2. Start the Frontend:
```powershell
cd C:\Subhash\Self-Driven\React_Project\Netflix_Subscription_System\frontend
npm run dev
```
*Frontend runs on `http://localhost:3000` with automatic proxying to port 8080.*

---
*Created with ❤️ for StreamSub - The Netflix Subscription & AI Recommendation Enterprise System.*
